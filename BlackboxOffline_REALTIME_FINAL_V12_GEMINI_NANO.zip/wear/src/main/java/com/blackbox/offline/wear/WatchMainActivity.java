package com.blackbox.offline.wear;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;

/**
 * Bulletproof Galaxy Watch 8 / Wear OS Controller.
 * Features:
 * - Safe initialization: no crash on startup
 * - Central interactive classic Blackbox monolith logo
 * - Inactive: monochrome slate logo. Active: vibrant solar amber logo with running timer
 * - Tap to start wrist recording -> stops and transfers WAV directly to smartphone
 */
public class WatchMainActivity extends Activity implements WatchAudioRecorder.Callback {
    private static final int PERM_REQ = 77;

    private ImageView logoView;
    private TextView timerText;
    private TextView statusText;

    private boolean isRecording = false;
    private long recordStartMs = 0;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private WatchAudioRecorder localRecorder;

    private final Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            if (isRecording) {
                long elapsed = (System.currentTimeMillis() - recordStartMs) / 1000;
                long mins = elapsed / 60;
                long secs = elapsed % 60;
                if (timerText != null) {
                    timerText.setText(String.format(java.util.Locale.US, "%02d:%02d", mins, secs));
                }
                mainHandler.postDelayed(this, 500);
            }
        }
    };

    private final BroadcastReceiver watchTransferReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String action = i != null ? i.getAction() : "";
            if (WatchTransferManager.ACTION_TRANSFER_STATUS.equals(action)) {
                String st = i.getStringExtra("status");
                if (st != null && statusText != null) {
                    statusText.setText(st);
                }
            } else if (WatchWearableListenerService.ACTION_TRANSCRIPT_RESULT.equals(action)) {
                String msg = i.getStringExtra("message");
                if (msg != null && statusText != null) {
                    statusText.setText(msg);
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            localRecorder = new WatchAudioRecorder(this, this);

            renderRoundLayout();

            IntentFilter filter = new IntentFilter();
            filter.addAction(WatchTransferManager.ACTION_TRANSFER_STATUS);
            filter.addAction(WatchWearableListenerService.ACTION_TRANSCRIPT_RESULT);

            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(watchTransferReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(watchTransferReceiver, filter);
            }

            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, PERM_REQ);
            }

            WatchTransferManager.queryPhoneState(this);
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    private void renderRoundLayout() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFFFFFFFF); // Light mono

        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER_HORIZONTAL);
        int padH = dp(16);
        int padV = dp(18);
        center.setPadding(padH, padV, padH, padV);

        TextView titleView = new TextView(this);
        titleView.setText("BLACKBOX");
        titleView.setTextColor(0xFF000000);
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        titleView.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        titleView.setLetterSpacing(0.04f);
        titleView.setMaxLines(1);
        titleView.setGravity(Gravity.CENTER);
        // КЛЮЧЕВОЙ ФИКС: без явных LayoutParams LinearLayout даёт заголовку
        // ширину MATCH_PARENT + выравнивание влево, и круглый экран срезает
        // левые буквы («ACKBOX»). Явные WRAP_CONTENT + CENTER_HORIZONTAL.
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-2, -2);
        tlp.gravity = Gravity.CENTER_HORIZONTAL;
        tlp.topMargin = dp(4);
        center.addView(titleView, tlp);

        // Interactive Monolith Logo as Start/Stop Button
        FrameLayout logoContainer = new FrameLayout(this);
        int logoBox = dp(84);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(logoBox, logoBox);
        clp.topMargin = dp(8);
        clp.bottomMargin = dp(8);
        logoContainer.setLayoutParams(clp);

        logoView = new ImageView(this);
        logoView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logoView.setClickable(true);
        logoView.setFocusable(true);
        updateLogoState(false);

        logoView.setOnClickListener(v -> onActionClick());
        logoContainer.addView(logoView, new FrameLayout.LayoutParams(-1, -1));
        center.addView(logoContainer);

        // Timer
        timerText = new TextView(this);
        timerText.setText("00:00");
        timerText.setTextColor(0xFF000000);
        timerText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        timerText.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        timerText.setVisibility(View.GONE);
        center.addView(timerText);

        // Status
        statusText = new TextView(this);
        statusText.setText("Коснитесь логотипа");
        statusText.setTextColor(0xFF6B6B6B);
        statusText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        statusText.setGravity(Gravity.CENTER);
        statusText.setMaxLines(2);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-2, -2);
        slp.topMargin = dp(2);
        center.addView(statusText, slp);

        root.addView(center, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        setContentView(root);
    }

    private void onActionClick() {
        vibrate(new long[]{0, 50});

        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO}, PERM_REQ);
            return;
        }

        if (isRecording) {
            if (localRecorder != null) localRecorder.stop();
            setLocalRecordingUi(false);
            if (statusText != null) statusText.setText("Отправка на смартфон...");
        } else {
            if (localRecorder != null) localRecorder.start();
        }
    }

    @Override
    public void onRecordingStarted() {
        mainHandler.post(() -> {
            vibrate(new long[]{0, 80});
            setLocalRecordingUi(true);
        });
    }

    @Override
    public void onRecordingFinished(File wavFile) {
        mainHandler.post(() -> {
            vibrate(new long[]{0, 50, 70, 50});
            setLocalRecordingUi(false);
            if (statusText != null) statusText.setText("Передано на смартфон ✓");
            WatchTransferManager.sendWavToPhone(this, wavFile);
        });
    }

    @Override
    public void onRecordingError(String error) {
        mainHandler.post(() -> {
            setLocalRecordingUi(false);
            if (statusText != null) statusText.setText(error);
            Toast.makeText(this, error, Toast.LENGTH_SHORT).show();
        });
    }

    private void setLocalRecordingUi(boolean active) {
        this.isRecording = active;
        updateLogoState(active);

        if (active) {
            recordStartMs = System.currentTimeMillis();
            if (timerText != null) {
                timerText.setVisibility(View.VISIBLE);
            }
            mainHandler.post(timerRunnable);
            if (statusText != null) {
                statusText.setText("● Запись на часах...");
                statusText.setTextColor(0xFFEF4444);
            }
        } else {
            mainHandler.removeCallbacks(timerRunnable);
            if (timerText != null) {
                timerText.setVisibility(View.GONE);
            }
            if (statusText != null) {
                statusText.setText("Коснитесь логотипа");
                statusText.setTextColor(0xFF6B6B6B);
            }
        }
    }

    private void updateLogoState(boolean recording) {
        if (logoView == null) return;
        int resId = recording
                ? getResources().getIdentifier("blackbox_mark", "drawable", getPackageName())
                : getResources().getIdentifier("blackbox_mark_mono", "drawable", getPackageName());
        if (resId != 0) {
            logoView.setImageResource(resId);
        }
    }

    private void vibrate(long[] pattern) {
        try {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null && v.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= 26) {
                    v.vibrate(VibrationEffect.createWaveform(pattern, -1));
                } else {
                    v.vibrate(pattern, -1);
                }
            }
        } catch (Throwable ignored) {}
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == PERM_REQ && res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) {
            onActionClick();
        } else {
            Toast.makeText(this, "Необходим микрофон", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        if (localRecorder != null && localRecorder.isRecording()) {
            localRecorder.stop();
        }
        mainHandler.removeCallbacks(timerRunnable);
        try { unregisterReceiver(watchTransferReceiver); } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
