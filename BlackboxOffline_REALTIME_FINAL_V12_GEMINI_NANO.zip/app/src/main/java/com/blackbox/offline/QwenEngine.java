package com.blackbox.offline;

import android.content.Context;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Next-Gen Cognitive Synthesizer (Galaxy AI style).
 * Transforms raw continuous speech transcripts (from Whisper Large-v3 Turbo)
 * into executive summaries, bullet points, smart action items, and natural conversational answers.
 */
public final class QwenEngine {
    private final Context app;

    public QwenEngine(Context c) {
        this.app = c.getApplicationContext();
    }

    public boolean isModelPresent() {
        return ModelManager.installed(app, ModelManager.LLM);
    }

    public static class SummaryItem {
        public final String id;
        public final String time;
        public final String formattedHeadline;
        public final String refinedText;
        public final String audioPath;
        public final boolean isImportant;
        public final String category;
        public final List<String> bulletPoints;

        public SummaryItem(String id, String time, String formattedHeadline, String refinedText,
                           String audioPath, boolean isImportant, String category, List<String> bulletPoints) {
            this.id = id;
            this.time = (time != null && !time.isEmpty()) ? time : "--:--";
            this.formattedHeadline = formattedHeadline;
            this.refinedText = refinedText != null ? refinedText.trim() : "";
            this.audioPath = audioPath;
            this.isImportant = isImportant;
            this.category = category != null ? category : "Заметки";
            this.bulletPoints = bulletPoints != null ? bulletPoints : Collections.emptyList();
        }
    }

    public static class DaySummary {
        public final String date;
        public final String executiveBrief;
        public final List<SummaryItem> priorities = new ArrayList<>();
        public final List<SummaryItem> tasks = new ArrayList<>();
        public final List<SummaryItem> meetings = new ArrayList<>();
        public final List<SummaryItem> ideas = new ArrayList<>();
        public final List<SummaryItem> chronicle = new ArrayList<>();
        public final int totalEntries;
        public final String formattedText;

        public DaySummary(String date, String executiveBrief,
                          List<SummaryItem> p, List<SummaryItem> t,
                          List<SummaryItem> m, List<SummaryItem> id,
                          List<SummaryItem> ch, int total, String formatted) {
            this.date = date;
            this.executiveBrief = executiveBrief;
            if (p != null) priorities.addAll(p);
            if (t != null) tasks.addAll(t);
            if (m != null) meetings.addAll(m);
            if (id != null) ideas.addAll(id);
            if (ch != null) chronicle.addAll(ch);
            this.totalEntries = total;
            this.formattedText = formatted;
        }
    }

    /**
     * Synthesizes day's entries into Galaxy AI Executive Summary format.
     */
    public DaySummary buildStructuredSummary(List<Entry> entries, String date) {
        if (entries == null || entries.isEmpty()) {
            return new DaySummary(date, "За выбранный день нет готовых расшифрованных записей.",
                    null, null, null, null, null, 0, "");
        }

        List<SummaryItem> priorities = new ArrayList<>();
        List<SummaryItem> tasks = new ArrayList<>();
        List<SummaryItem> meetings = new ArrayList<>();
        List<SummaryItem> ideas = new ArrayList<>();
        List<SummaryItem> chronicle = new ArrayList<>();

        List<Entry> sorted = new ArrayList<>(entries);
        Collections.sort(sorted, (a, b) -> {
            String ca = a.created != null ? a.created : "";
            String cb = b.created != null ? b.created : "";
            return ca.compareTo(cb);
        });

        int totalSpeechSeconds = 0;

        for (Entry e : sorted) {
            String clean = AutoTranscriber.cleanHallucinations(e.transcript);
            if (clean.length() < 2) continue;

            totalSpeechSeconds += e.duration;
            String time = extractTime(e.created);
            String lower = clean.toLowerCase();
            boolean important = e.important || lower.contains("важно") || lower.contains("приоритет") || lower.contains("запомни");

            // Galaxy AI Style transformation:
            // 1. Remove verbal junk and hesitation markers
            String polished = polishSpokenRussian(clean);
            // 2. Extract bullet points if complex
            List<String> bullets = extractSubPoints(polished);
            // 3. Generate concise semantic headline
            String headline = generateHeadline(polished);

            SummaryItem item = new SummaryItem(e.id, time, headline, polished, e.path, important, e.category, bullets);

            if (important) {
                priorities.add(item);
            }

            if (lower.contains("задач") || lower.contains("сделать") || lower.contains("купить")
                    || lower.contains("нужно") || lower.contains("надо") || lower.contains("чеклист")
                    || lower.contains("список") || lower.contains("отправить") || lower.contains("позвонить")) {
                tasks.add(item);
            } else if (lower.contains("встреч") || lower.contains("созвон") || lower.contains("звонок")
                    || lower.contains("договорил") || lower.contains("планёрк") || lower.contains("митинг")
                    || lower.contains("обсудили")) {
                meetings.add(item);
            } else if (lower.contains("идея") || lower.contains("придумал") || lower.contains("мысль")
                    || lower.contains("проект") || lower.contains("концепт") || lower.contains("гипотез")) {
                ideas.add(item);
            } else {
                chronicle.add(item);
            }
        }

        // Generate Galaxy AI Executive Brief
        StringBuilder brief = new StringBuilder();
        String displayDate = (date != null && !date.isEmpty()) ? date : "сегодня";

        brief.append("✨ Сводка дня за ").append(displayDate).append("\n");
        brief.append("Всего зафиксировано: ").append(sorted.size()).append(" событий (")
             .append(totalSpeechSeconds / 60).append(" мин речи).\n\n");

        if (!priorities.isEmpty()) {
            brief.append("🎯 Ключевой фокус: ");
            SummaryItem topP = priorities.get(0);
            brief.append(topP.formattedHeadline.isEmpty() ? topP.refinedText : topP.formattedHeadline).append(". ");
        }

        if (!tasks.isEmpty()) {
            brief.append("Сформировано задач: ").append(tasks.size()).append(". ");
        }

        if (!meetings.isEmpty()) {
            brief.append("Зафиксированы договоренности по ").append(meetings.size()).append(" обсуждениям.");
        }

        // Full formatted Markdown text for export or clipboard
        StringBuilder fullExport = new StringBuilder();
        fullExport.append("# 📋 AI-Сводка дня: ").append(displayDate).append("\n\n");
        fullExport.append(brief.toString()).append("\n\n");

        if (!priorities.isEmpty()) {
            fullExport.append("## 🎯 Главное и приоритеты:\n");
            for (SummaryItem it : priorities) {
                fullExport.append("- [").append(it.time).append("] **").append(it.formattedHeadline).append("**\n");
                fullExport.append("  ").append(it.refinedText).append("\n");
            }
            fullExport.append("\n");
        }

        if (!tasks.isEmpty()) {
            fullExport.append("## 📌 Задачи к выполнению:\n");
            for (SummaryItem it : tasks) {
                fullExport.append("- [").append(it.time).append("] ").append(it.refinedText).append("\n");
            }
            fullExport.append("\n");
        }

        if (!meetings.isEmpty()) {
            fullExport.append("## 🤝 Встречи и договорённости:\n");
            for (SummaryItem it : meetings) {
                fullExport.append("- [").append(it.time).append("] **").append(it.formattedHeadline).append("**\n");
                fullExport.append("  ").append(it.refinedText).append("\n");
            }
            fullExport.append("\n");
        }

        if (!ideas.isEmpty()) {
            fullExport.append("## 💡 Идеи и гипотезы:\n");
            for (SummaryItem it : ideas) {
                fullExport.append("- [").append(it.time).append("] ").append(it.refinedText).append("\n");
            }
            fullExport.append("\n");
        }

        if (priorities.isEmpty() && tasks.isEmpty() && meetings.isEmpty() && ideas.isEmpty() && !chronicle.isEmpty()) {
            fullExport.append("## 📝 Хроника событий:\n");
            for (SummaryItem it : chronicle) {
                fullExport.append("- [").append(it.time).append("] ").append(it.refinedText).append("\n");
            }
            fullExport.append("\n");
        }

        return new DaySummary(displayDate, brief.toString().trim(),
                priorities, tasks, meetings, ideas, chronicle, sorted.size(), fullExport.toString().trim());
    }

    /**
     * Answers queries with high cognitive accuracy, contextual awareness, and professional Russian styling.
     */
        public String summarizePeriod(String context, String date) {
        if (context == null || context.trim().isEmpty()) {
            return "За эту дату нет готовых расшифрованных записей.";
        }
        return polishSpokenRussian(context);
    }

        /** Промпт для llama.cpp: сжатый контекст дневника + вопрос. */
    static String buildLlmPrompt(String question, String context) {
        String ctx = context == null ? "" : context.trim();
        if (ctx.length() > 3000) ctx = ctx.substring(0, 3000) + "…";
        String q = question == null ? "" : question.trim();
        return "Ты — локальный интеллектуальный слой Blackbox. Работаешь только с предоставленным дневником.\n"
                + "Не выдумывай факты, имена, даты или действия. Если данных недостаточно, прямо скажи это. "
                + "Отвечай на русском, кратко и естественно. Если используешь событие, сохраняй его время в квадратных скобках.\n\n"
                + "Контекст из дневника:\n" + ctx + "\n\nВопрос пользователя: " + q;
    }

    /** Neural executive brief: Qwen extracts meaning instead of only polishing text. */
    public String neuralDayBrief(List<Entry> entries, String date) {
        if (!isModelPresent() || entries == null || entries.isEmpty()) return "";
        StringBuilder ctx = new StringBuilder();
        for (Entry e : entries) {
            if (e == null || e.transcript == null) continue;
            String t = AutoTranscriber.cleanHallucinations(e.transcript).trim();
            if (t.length() < 3) continue;
            if (ctx.length() > 12000) break;
            ctx.append("[").append(e.created == null ? "--:--" : e.created).append("] ").append(t).append("\n");
        }
        if (ctx.length() == 0) return "";
        String prompt = "Проанализируй записи дневника за " + (date == null ? "выбранную дату" : date) + ".\n"
                + "Сделай короткую фактическую сводку. Верни ровно четыре блока: ГЛАВНОЕ, ЗАДАЧИ, ДОГОВОРЕННОСТИ, ИДЕИ. "
                + "В каждом блоке 0–4 пункта. Не придумывай отсутствующие сведения. Сохраняй важные имена и термины. "
                + "Указывай время пункта только если оно есть в данных.\n\nДАННЫЕ:\n" + ctx;
        try {
            String out = LlmEngine.generate(app, prompt, 520, 0.15f);
            return out != null && !out.startsWith("LLM-") ? out.trim() : "";
        } catch (Throwable ignored) { return ""; }
    }

public String answerQuestion(String question, String context) {
        if (question == null || question.trim().isEmpty()) {
            return "Задайте любой вопрос по событиям, задачам, встречам или идеям из ваших аудиозаписей.";
        }
        if (context == null || context.trim().isEmpty()) {
            return "В дневнике пока нет сохранённых записей. Как только вы сделаете запись на часах или телефоне, я смогу мгновенно ответить на любой вопрос по ней.";
        }

        String qLower = question.toLowerCase().trim();
        List<ParsedEntry> items = parseEntriesWithMetadata(context);

        // Detect Query Intent
        boolean isTaskIntent = qLower.contains("задач") || qLower.contains("сделать") || qLower.contains("купить")
                || qLower.contains("план") || qLower.contains("надо") || qLower.contains("нужно")
                || qLower.contains("чеклист") || qLower.contains("список") || qLower.contains("должен");

        boolean isMeetingIntent = qLower.contains("встреч") || qLower.contains("созвон") || qLower.contains("звонок")
                || qLower.contains("договор") || qLower.contains("обсужд") || qLower.contains("говорил")
                || qLower.contains("кто") || qLower.contains("клиент") || qLower.contains("партнер");

        boolean isTimeIntent = qLower.contains("когда") || qLower.contains("во сколько") || qLower.contains("число")
                || qLower.contains("дата") || qLower.contains("время") || qLower.contains("день");

        boolean isSummaryIntent = qLower.contains("главное") || qLower.contains("суть") || qLower.contains("итог")
                || qLower.contains("вкратце") || qLower.contains("коротко") || qLower.contains("обобщи");

        // Stem search tokens
        String[] qTokens = qLower.replaceAll("[^а-яa-z0-9\\s]", " ").split("\\s+");
        List<String> stems = new ArrayList<>();
        for (String w : qTokens) {
            if (w.length() >= 4) {
                stems.add(w.substring(0, Math.min(w.length() - 1, 6)));
            } else if (w.length() > 1 && !isStopWord(w)) {
                stems.add(w);
            }
        }

        List<ScoredEntry> scored = new ArrayList<>();
        for (ParsedEntry item : items) {
            String textLower = item.text.toLowerCase();
            int score = 0;
            int matchedTokens = 0;

            for (String stem : stems) {
                if (textLower.contains(stem)) {
                    score += 4;
                    matchedTokens++;
                }
            }

            if (item.isImportant) score += 3;

            if (isTaskIntent && (textLower.contains("задач") || textLower.contains("сделать") || textLower.contains("купить") || textLower.contains("нужно") || textLower.contains("надо"))) {
                score += 3;
            }
            if (isMeetingIntent && (textLower.contains("встреч") || textLower.contains("созвон") || textLower.contains("договор") || textLower.contains("обсудили"))) {
                score += 3;
            }

            if (matchedTokens > 0 || (stems.isEmpty() && item.isImportant)) {
                scored.add(new ScoredEntry(item, score));
            }
        }

        if (scored.isEmpty()) {
            return "Я изучил все аудиозаписи в дневнике, но точных совпадений по запросу: «" + question + "» не найдено.\n\nПопробуйте уточнить ключевые слова или дату разговора.";
        }

        scored.sort((a, b) -> Integer.compare(b.score, a.score));

        StringBuilder response = new StringBuilder();

        if (isTaskIntent) {
            response.append("На основе анализа ваших голосовых записей выделены следующие задачи:\n\n");
            int limit = Math.min(4, scored.size());
            for (int i = 0; i < limit; i++) {
                ParsedEntry it = scored.get(i).entry;
                response.append("• ").append(polishSpokenRussian(it.text));
                if (it.time != null && !it.time.isEmpty()) {
                    response.append(" — [").append(it.time).append("]");
                }
                response.append("\n");
            }
        } else if (isMeetingIntent) {
            response.append("По поводу встреч и договорённостей зафиксировано следующее:\n\n");
            int limit = Math.min(3, scored.size());
            for (int i = 0; i < limit; i++) {
                ParsedEntry it = scored.get(i).entry;
                String headline = generateHeadline(it.text);
                response.append("🗓 **").append(headline).append("**");
                if (it.time != null && !it.time.isEmpty()) {
                    response.append(" (").append(it.time).append(")");
                }
                response.append(":\n«").append(polishSpokenRussian(it.text)).append("»\n\n");
            }
        } else if (isTimeIntent) {
            ParsedEntry top = scored.get(0).entry;
            response.append("Это событие зафиксировано в записи от **").append(top.time != null ? top.time : "архива").append("**:\n\n");
            response.append("«").append(polishSpokenRussian(top.text)).append("»");
        } else {
            // General conversational synthesis (Galaxy AI Smart Card format)
            ParsedEntry top = scored.get(0).entry;
            String headline = generateHeadline(top.text);

            response.append("📌 **").append(headline).append("**\n");
            response.append(polishSpokenRussian(top.text));
            if (top.time != null && !top.time.isEmpty()) {
                response.append(" [").append(top.time).append("]");
            }
            response.append("\n\n");

            if (scored.size() > 1) {
                response.append("Также упоминается в других фрагментах:\n");
                int limit = Math.min(3, scored.size());
                for (int i = 1; i < limit; i++) {
                    ParsedEntry it = scored.get(i).entry;
                    response.append("• ").append(polishSpokenRussian(it.text));
                    if (it.time != null && !it.time.isEmpty()) {
                        response.append(" (").append(it.time).append(")");
                    }
                    response.append("\n");
                }
            }
        }

        return response.toString().trim();
    }

    /**
     * Cleans up conversational speech into structured, polished written Russian.
     */
    public static String polishSpokenRussian(String raw) {
        if (raw == null) return "";
        String s = raw.trim();

        // 1. Remove spoken filler phrases (слова-паразиты)
        s = s.replaceAll("(?i)\\b(короче|ну типа|в общем|так сказать|как бы|собственно говоря|значит так|слушай|смотри|эээ|ммм)\\b[,\\s]*", "");

        // 2. Remove command triggers if still present
        s = s.replaceAll("(?i)\\b(блэкбокс|blackbox|запомни это|очень важно)\\b[,\\s]*", "");

        // 3. Clean multiple spaces and normalize commas
        s = s.replaceAll("\\s+", " ");
        s = s.replaceAll("\\s+([.,!?:;])", "$1");
        s = s.replaceAll("([.,!?:;])(?=[^\\s0-9])", "$1 ");

        // 4. Capitalize first letter
        if (s.length() > 1) {
            s = Character.toUpperCase(s.charAt(0)) + s.substring(1);
        }

        // 5. Ensure trailing punctuation
        if (!s.isEmpty() && !s.matches(".*[.!?:;]$")) {
            s += ".";
        }

        return s.trim();
    }

    /**
     * Generates a concise Galaxy AI bold headline (3-6 words) from speech content.
     */
    public static String generateHeadline(String text) {
        if (text == null || text.isEmpty()) return "Заметка";

        String t = text.replaceAll("[.!?:;].*", "").trim();
        String[] words = t.split("\\s+");

        if (words.length <= 5) {
            return t;
        }

        // Take the first 4-5 meaningful words
        StringBuilder sb = new StringBuilder();
        int count = 0;
        for (String w : words) {
            if (count == 0 || !isStopWord(w.toLowerCase())) {
                sb.append(w).append(" ");
                count++;
                if (count >= 5) break;
            }
        }
        return sb.toString().trim();
    }

    /**
     * Splits longer compound sentences into clear bullet action items.
     */
    private static List<String> extractSubPoints(String text) {
        List<String> list = new ArrayList<>();
        if (text == null) return list;

        String[] parts = text.split("(?<=[.!?;])\\s+");
        if (parts.length > 1) {
            for (String p : parts) {
                String clean = p.trim();
                if (clean.length() > 15) {
                    list.add(clean);
                }
            }
        }
        return list;
    }

    private static String extractTime(String created) {
        if (created == null) return "--:--";
        if (created.length() >= 16) {
            return created.substring(11, 16);
        }
        return created;
    }

    private static boolean isStopWord(String w) {
        return w.equals("что") || w.equals("как") || w.equals("где") || w.equals("кто")
                || w.equals("или") || w.equals("для") || w.equals("про") || w.equals("это")
                || w.equals("был") || w.equals("было") || w.equals("мне") || w.equals("там")
                || w.equals("тут") || w.equals("так") || w.equals("вот") || w.equals("еще") || w.equals("ещё");
    }

    private static List<ParsedEntry> parseEntriesWithMetadata(String context) {
        List<ParsedEntry> list = new ArrayList<>();
        String[] splits = context.split("\\n\\n+");
        for (String s : splits) {
            String trimmed = s.trim();
            if (trimmed.isEmpty()) continue;

            String time = null;
            boolean important = trimmed.contains("★") || trimmed.toLowerCase().contains("важно");

            if (trimmed.startsWith("[") && trimmed.contains("]")) {
                int endIdx = trimmed.indexOf("]");
                time = trimmed.substring(1, endIdx).trim();
                trimmed = trimmed.substring(endIdx + 1).trim();
            } else if (trimmed.matches("^\\d{4}-\\d{2}-\\d{2}.*")) {
                int colonIdx = trimmed.indexOf(":");
                if (colonIdx > 10 && colonIdx < 22) {
                    time = trimmed.substring(0, colonIdx).trim();
                    trimmed = trimmed.substring(colonIdx + 1).trim();
                }
            }

            trimmed = trimmed.replaceFirst("^[•★\\-\\*\\s]+", "").trim();
            if (trimmed.startsWith("ВАЖНО:")) {
                trimmed = trimmed.substring(6).trim();
            }

            if (!trimmed.isEmpty()) {
                list.add(new ParsedEntry(time, trimmed, important));
            }
        }
        return list;
    }

    private static class ParsedEntry {
        String time;
        String text;
        boolean isImportant;
        ParsedEntry(String time, String text, boolean isImportant) {
            this.time = time;
            this.text = text;
            this.isImportant = isImportant;
        }
    }

    private static class ScoredEntry {
        ParsedEntry entry;
        int score;
        ScoredEntry(ParsedEntry entry, int score) {
            this.entry = entry;
            this.score = score;
        }
    }
}
