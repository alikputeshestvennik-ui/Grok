package com.blackbox.offline;

import android.app.Activity;
import android.content.Context;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * «Чёрный ящик» — светлая монохромная система (white canvas · black ink).
 * Палитра и кнопки по референсу: белый фон, чёрные solid-кнопки, чистая типографика.
 * Механика не затрагивается — только цвета, формы, отступы.
 */
public final class UI {
    // Canvas
    public static final int COLOR_BG = 0xFFF6F7F8;
    public static final int COLOR_SURFACE = 0xFFFFFFFF;
    public static final int COLOR_SURFACE_ELEVATED = 0xFFF1F3F5;
    public static final int COLOR_SURFACE_HIGH = 0xFFE9ECEF;
    public static final int COLOR_SURFACE_HOVER = 0xFFE1E4E8;
    public static final int COLOR_BORDER = 0xFFD7DBE0;
    public static final int COLOR_BORDER_BRIGHT = 0xFFB2B8C0;

    public static final int SHADOW_WARM = 0x18000000;

    // Brand = pure black (was amber)
    public static final int COLOR_ORANGE = 0xFFE77A2B;
    public static final int COLOR_ORANGE_LIGHT = 0xFFF0A36A;
    public static final int COLOR_ORANGE_CORE = 0xFFD9671F;
    public static final int COLOR_ORANGE_DIM = 0x18E77A2B;
    public static final int COLOR_ORANGE_BORDER = 0xFFE77A2B;

    // Live accent — soft graphite (recording indicator)
    public static final int COLOR_LIVE = 0xFF66707A;
    public static final int COLOR_LIVE_DIM = 0x1466707A;
    public static final int COLOR_LIVE_BORDER = 0xFFAAB2BB;

    public static final int COLOR_IMPORTANT_BG = 0xFFF0F2F4;
    public static final int COLOR_IMPORTANT_BORDER = 0xFFD2D7DC;

    public static final int COLOR_GREEN = 0xFF1B7A3D;
    public static final int COLOR_GREEN_BG = 0x1A1B7A3D;
    public static final int COLOR_RED = 0xFFC62828;
    public static final int COLOR_RED_BG = 0x1AC62828;
    public static final int COLOR_RED_GRAD_END = 0xFF8E0000;

    public static final int COLOR_TEXT_TITLE = 0xFF000000;
    public static final int COLOR_TEXT_PRIMARY = 0xFF111111;
    public static final int COLOR_TEXT_MUTED = 0xFF6B6B6B;
    public static final int COLOR_TEXT_SUBTLE = 0xFF9E9E9E;
    public static final int COLOR_TEXT_ORANGE = 0xFF000000;

    public static final int COLOR_NAV_INACTIVE = 0xFF8D949C;
    public static final int COLOR_NAV_ACTIVE = 0xFFE77A2B;
    public static final int COLOR_NAV_BAR = 0xF2FFFFFF;

    private UI() {}

    public static int dp(Context c, int v) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }

    public static GradientDrawable shape(int fill, int stroke, int radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (stroke != 0) g.setStroke(dp(c, 1), stroke);
        return g;
    }

    public static GradientDrawable shape(int fill, int radiusDp, Context c) {
        return shape(fill, 0, radiusDp, c);
    }

    public static void elevate(View v, float dpElev) {
        if (Build.VERSION.SDK_INT >= 21) {
            v.setElevation(dpElev * v.getResources().getDisplayMetrics().density);
        }
    }

    public static LinearLayout createCard(Context c) {
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(c, 16);
        card.setPadding(pad, pad, pad, pad);
        card.setBackground(shape(COLOR_SURFACE, COLOR_BORDER, 16, c));
        elevate(card, 1f);
        return card;
    }

    public static Button primaryButton(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        b.setBackground(shape(0xFF000000, 14, c));
        b.setPadding(dp(c, 18), dp(c, 14), dp(c, 18), dp(c, 14));
        b.setMinHeight(dp(c, 48));
        if (Build.VERSION.SDK_INT >= 21) {
            b.setStateListAnimator(null);
            b.setElevation(0);
        }
        return b;
    }

    public static Button secondaryButton(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(0xFF000000);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setBackground(shape(0xFFFFFFFF, 0xFF000000, 14, c));
        b.setPadding(dp(c, 16), dp(c, 12), dp(c, 16), dp(c, 12));
        b.setMinHeight(dp(c, 44));
        if (Build.VERSION.SDK_INT >= 21) {
            b.setStateListAnimator(null);
            b.setElevation(0);
        }
        return b;
    }

    public static TextView badge(Context c, String text, int fg, int bg) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextColor(fg);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        int ph = dp(c, 10);
        int pv = dp(c, 5);
        t.setPadding(ph, pv, ph, pv);
        t.setBackground(shape(bg, 10, c));
        return t;
    }

    public static EditText inputField(Context c, String hint) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setHintTextColor(COLOR_TEXT_SUBTLE);
        e.setTextColor(COLOR_TEXT_PRIMARY);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        e.setBackground(shape(COLOR_SURFACE_ELEVATED, COLOR_BORDER, 12, c));
        e.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12));
        e.setSingleLine(false);
        return e;
    }

    /** Compatibility helpers used by the activity screens. */
    public static LinearLayout createHeader(Activity a, String title, String subtitle, boolean showBack) {
        return topBar(a, title, subtitle, showBack);
    }

    public static GradientDrawable gradient(int startColor, int endColor, int radiusDp, Context c) {
        GradientDrawable g = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{startColor, endColor});
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    public static RippleDrawable buttonRipple(GradientDrawable base, int rippleColor) {
        if (Build.VERSION.SDK_INT >= 21) {
            return new RippleDrawable(ColorStateList.valueOf(rippleColor), base, null);
        }
        // RippleDrawable is unavailable below API 21; all supported project devices
        // use API 21+, so this branch is only a defensive fallback.
        return null;
    }

    public static void copyToClipboard(Context c, String label, String text) {
        ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText(label, text == null ? "" : text));
    }

    public static void attachPressScale(View v) {
        v.setOnTouchListener((view, event) -> {
            switch (event.getActionMasked()) {
                case android.view.MotionEvent.ACTION_DOWN:
                    view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(70).start();
                    break;
                case android.view.MotionEvent.ACTION_UP:
                case android.view.MotionEvent.ACTION_CANCEL:
                    view.animate().scaleX(1f).scaleY(1f).setDuration(90).start();
                    break;
            }
            return false;
        });
    }

    public static View navCardButton(Context c, String iconName, String title, String subtitle,
                                     View.OnClickListener listener) {
        LinearLayout card = createCard(c);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = new TextView(c);
        icon.setText(iconName == null ? "" : iconName);
        icon.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        icon.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(dp(c, 44), dp(c, 44));
        ilp.rightMargin = dp(c, 12);
        card.addView(icon, ilp);

        LinearLayout text = new LinearLayout(c);
        text.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(c);
        t.setText(title);
        t.setTextColor(COLOR_TEXT_PRIMARY);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        text.addView(t);
        if (subtitle != null && !subtitle.isEmpty()) {
            TextView s = new TextView(c);
            s.setText(subtitle);
            s.setTextColor(COLOR_TEXT_MUTED);
            s.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            text.addView(s);
        }
        card.addView(text, new LinearLayout.LayoutParams(0, -2, 1f));
        card.setOnClickListener(listener);
        return card;
    }

    public static LinearLayout createImportantCard(Context c) {
        LinearLayout card = createCard(c);
        card.setBackground(shape(COLOR_IMPORTANT_BG, COLOR_IMPORTANT_BORDER, 16, c));
        return card;
    }

    public static LinearLayout createLiveCard(Context c) {
        LinearLayout card = createCard(c);
        card.setBackground(shape(0xFFF0F2F4, COLOR_LIVE_BORDER, 16, c));
        return card;
    }

    public static LinearLayout topBar(Activity a, String title, String subtitle, boolean showBack) {
        Context c = a;
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.VERTICAL);
        int topInset = 0;
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                View decor = a.getWindow().getDecorView();
                topInset = decor.getRootWindowInsets() != null
                        ? decor.getRootWindowInsets().getSystemWindowInsetTop() : 0;
            }
        } catch (Throwable ignored) {}
        bar.setPadding(dp(c, 18), topInset + dp(c, 8), dp(c, 18), dp(c, 14));
        bar.setBackgroundColor(COLOR_BG);

        if (showBack) {
            LinearLayout backRow = new LinearLayout(c);
            backRow.setOrientation(LinearLayout.HORIZONTAL);
            backRow.setGravity(Gravity.CENTER_VERTICAL);
            backRow.setPadding(0, dp(c, 2), dp(c, 16), dp(c, 10));
            TextView chevron = new TextView(c);
            chevron.setText("‹");
            chevron.setTextColor(COLOR_TEXT_PRIMARY);
            chevron.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
            chevron.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            backRow.addView(chevron);
            TextView backText = new TextView(c);
            backText.setText(" Назад");
            backText.setTextColor(COLOR_TEXT_PRIMARY);
            backText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            backText.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            backRow.addView(backText);
            backRow.setOnClickListener(v -> a.finish());
            bar.addView(backRow);
        }

        LinearLayout titleRow = new LinearLayout(c);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);

        // Real Blackbox mark from the supplied logo reference.
        ImageView mark = new ImageView(c);
        mark.setImageResource(c.getResources().getIdentifier("blackbox_mark", "drawable", c.getPackageName()));
        mark.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        mark.setBackground(shape(0xFFFFFFFF, COLOR_BORDER, 10, c));
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(dp(c, 40), dp(c, 40));
        mlp.rightMargin = dp(c, 12);
        titleRow.addView(mark, mlp);

        LinearLayout textCol = new LinearLayout(c);
        textCol.setOrientation(LinearLayout.VERTICAL);

        TextView tvTitle = new TextView(c);
        tvTitle.setText(title);
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        tvTitle.setTextColor(COLOR_TEXT_TITLE);
        tvTitle.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        textCol.addView(tvTitle);

        if (subtitle != null && !subtitle.isEmpty()) {
            TextView tvSub = new TextView(c);
            tvSub.setText(subtitle);
            tvSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            tvSub.setTextColor(COLOR_TEXT_MUTED);
            tvSub.setPadding(0, dp(c, 2), 0, 0);
            textCol.addView(tvSub);
        }

        titleRow.addView(textCol);
        bar.addView(titleRow);
        return bar;
    }
}
