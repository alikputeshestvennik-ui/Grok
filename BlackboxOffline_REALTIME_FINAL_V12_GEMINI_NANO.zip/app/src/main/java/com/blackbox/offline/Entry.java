package com.blackbox.offline;

import org.json.JSONException;
import org.json.JSONObject;

public class Entry {
    public String id;
    public String path;
    public String created;
    public String transcript;
    public String summary;
    public String status;
    public String category;
    public long duration;
    public boolean important;
    /** Whisper ready, waiting for cloud/Nano polish when online. */
    public boolean cloudPending;
    // Не сериализуется в EntryStore — живёт только в памяти на время одного
    // клипа. Нужен, чтобы hands-free вопрос к памяти («Блэкбокс, где...»),
    // уже отвеченный быстрым путём через живой Vosk, не отвечался ЕЩЁ РАЗ
    // на финальном тексте Whisper (два похожих пуша на один и тот же вопрос).
    public transient volatile boolean handsFreeHandled = false;

    public Entry(String id, String path, String created, long duration, String transcript, String summary) {
        this(id, path, created, duration, transcript, summary, "Общее");
    }

    public Entry(String id, String path, String created, long duration, String transcript, String summary, String category) {
        this.id = id;
        this.path = path;
        this.created = created;
        this.duration = duration;
        this.transcript = transcript != null ? transcript : "";
        this.summary = summary != null ? summary : "";
        this.status = this.transcript.isEmpty() ? "В очереди" : "Готово";
        this.category = (category != null && !category.isEmpty()) ? category : "Общее";
        this.important = false;
        this.cloudPending = false;
    }

    public JSONObject json() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("path", path);
        o.put("created", created);
        o.put("duration", duration);
        o.put("transcript", transcript);
        o.put("summary", summary);
        o.put("important", important);
        o.put("cloudPending", cloudPending);
        o.put("status", status);
        o.put("category", category);
        return o;
    }

    public static Entry from(JSONObject o) {
        Entry e = new Entry(
                o.optString("id"),
                o.optString("path"),
                o.optString("created"),
                o.optLong("duration"),
                o.optString("transcript"),
                o.optString("summary"),
                o.optString("category", "Общее")
        );
        e.important = o.optBoolean("important", false);
        e.cloudPending = o.optBoolean("cloudPending", false);
        e.status = o.optString("status", e.transcript.isEmpty() ? "В очереди" : "Готово");
        return e;
    }
}
