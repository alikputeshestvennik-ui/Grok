package com.blackbox.offline;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Rolling realtime transcript buffer: keeps only the last 15 minutes
 * by wall-clock time (not by audio length). Separate from diary History.
 */
public final class RealtimeRingStore {
    public static final long WINDOW_MS = 15 * 60 * 1000L;
    private static final String FILE = "realtime_ring.json";
    private static final Object LOCK = new Object();

    public static final class Item {
        public final long ts;
        public final String text;
        public Item(long ts, String text) {
            this.ts = ts;
            this.text = text == null ? "" : text.trim();
        }
        public String timeLabel() {
            return new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date(ts));
        }
    }

    private RealtimeRingStore() {}

    /** Add only a finalized utterance to the realtime ring. */
    public static void appendFinal(Context c, String text) {
        if (text == null) return;
        text = text.trim();
        if (text.length() < 2) return;
        synchronized (LOCK) {
            ArrayList<Item> items = loadLocked(c);
            long now = System.currentTimeMillis();
            if (!items.isEmpty()) {
                Item last = items.get(items.size() - 1);
                if (last.text.equals(text) && now - last.ts < 5000) {
                    pruneLocked(items, now);
                    saveLocked(c, items);
                    return;
                }
            }
            items.add(new Item(now, text));
            pruneLocked(items, now);
            saveLocked(c, items);
        }
    }

    public static ArrayList<Item> snapshot(Context c) {
        synchronized (LOCK) {
            ArrayList<Item> items = loadLocked(c);
            pruneLocked(items, System.currentTimeMillis());
            saveLocked(c, items);
            return new ArrayList<>(items);
        }
    }

    public static void clear(Context c) {
        synchronized (LOCK) {
            saveLocked(c, new ArrayList<>());
        }
    }

    private static void pruneLocked(ArrayList<Item> items, long now) {
        long cut = now - WINDOW_MS;
        while (!items.isEmpty() && items.get(0).ts < cut) {
            items.remove(0);
        }
    }

    private static File file(Context c) {
        return new File(c.getApplicationContext().getFilesDir(), FILE);
    }

    private static ArrayList<Item> loadLocked(Context c) {
        ArrayList<Item> out = new ArrayList<>();
        File f = file(c);
        if (!f.isFile()) return out;
        try {
            String raw;
            try (InputStream in = new FileInputStream(f)) {
                byte[] b = new byte[(int) f.length()];
                int n = in.read(b);
                raw = n > 0 ? new String(b, 0, n, "UTF-8") : "[]";
            }
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                out.add(new Item(o.optLong("ts"), o.optString("text", "")));
            }
        } catch (Throwable ignored) {}
        return out;
    }

    private static void saveLocked(Context c, ArrayList<Item> items) {
        try {
            JSONArray arr = new JSONArray();
            for (Item it : items) {
                JSONObject o = new JSONObject();
                o.put("ts", it.ts);
                o.put("text", it.text);
                arr.put(o);
            }
            File f = file(c);
            File tmp = new File(f.getAbsolutePath() + ".part");
            try (OutputStream os = new FileOutputStream(tmp)) {
                os.write(arr.toString().getBytes("UTF-8"));
            }
            if (f.exists()) f.delete();
            tmp.renameTo(f);
        } catch (Throwable ignored) {}
    }
}
