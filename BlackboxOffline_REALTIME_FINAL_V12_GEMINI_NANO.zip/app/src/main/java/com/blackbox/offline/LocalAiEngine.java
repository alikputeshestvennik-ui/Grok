package com.blackbox.offline;

import android.content.Context;
import java.io.File;
import java.util.List;

/**
 * Local Whisper + system Gemini Nano (AICore) bridge.
 * Application has NO android.permission.INTERNET.
 *
 * Post-ASR editing and memory/report generation prefer on-device Gemini Nano.
 * If Nano is absent → raw Whisper text / template fallbacks (never force GGUF for editing).
 */
public class LocalAiEngine {
    private final Context app;
    private final QwenEngine qwenEngine;
    private static volatile boolean whisperLoaded = false;
    private static volatile boolean attempted = false;
    private static final Object WARM_LOCK = new Object();
    private static volatile boolean warmed = false;

    public LocalAiEngine(Context c) {
        this.app = c.getApplicationContext();
        this.qwenEngine = new QwenEngine(app);
    }

    private static synchronized void ensureNative() {
        if (!attempted) {
            attempted = true;
            try {
                System.loadLibrary("blackbox_ai");
                whisperLoaded = true;
            } catch (Throwable t) {
                whisperLoaded = false;
            }
        }
    }

    public boolean whisperReady() {
        ensureNative();
        return whisperLoaded && ModelManager.installed(app, ModelManager.WHISPER);
    }

    public boolean qwenReady() {
        return qwenEngine.isModelPresent();
    }

    public boolean geminiNanoReady() {
        return GeminiNanoEngine.isAvailable(app);
    }

    public boolean ready() {
        return whisperReady();
    }

    private static native boolean nativeWarm(String modelPath);

    /** Подогрев Whisper-контекста. */
    public static boolean warm(Context c) {
        try {
            Context app = c.getApplicationContext();
            ensureNative();
            if (!whisperLoaded || !ModelManager.installed(app, ModelManager.WHISPER)) return false;
            if (warmed) return true;
            synchronized (WARM_LOCK) {
                if (warmed) return true;
                boolean ok = nativeWarm(ModelManager.file(app, ModelManager.WHISPER).getAbsolutePath());
                if (ok) warmed = true;
                return ok;
            }
        } catch (Throwable t) {
            return false;
        }
    }

    public String transcribe(String path) throws Exception {
        if (!ModelManager.installed(app, ModelManager.WHISPER)) {
            throw new IllegalStateException("Импортируйте ggml-base.bin в разделе AI-модели.");
        }
        ensureNative();
        if (!whisperLoaded) {
            throw new IllegalStateException("Нативная библиотека whisper не загружена.");
        }
        File model = ModelManager.file(app, ModelManager.WHISPER);
        return nativeTranscribePcm(PcmDecoder.decode16kMono(path), model.getAbsolutePath());
    }

    /**
     * Post-Whisper edit via system Gemini Nano.
     * Returns Nano result, or original text when Nano is unavailable (Whisper passthrough).
     */
    public String editTranscript(String rawAsr) {
        if (rawAsr == null || rawAsr.trim().isEmpty()) return "";
        String nano = GeminiNanoEngine.editTranscript(app, rawAsr.trim());
        if (nano != null && nano.trim().length() >= 3) return nano.trim();
        return rawAsr.trim();
    }

    public String shortenSummary(String text) {
        if (text == null || text.trim().isEmpty()) return "";
        String nano = GeminiNanoEngine.shorten(app, text);
        if (nano != null && nano.trim().length() >= 3) return nano.trim();
        String t = text.trim();
        if (t.length() <= 280) return t;
        return t.substring(0, 277) + "…";
    }

    public String hourlyReport24h(List<Entry> entries) {
        if (entries == null || entries.isEmpty()) {
            return "За последние 24 часа готовых записей нет.";
        }
        StringBuilder ctx = new StringBuilder();
        for (Entry e : entries) {
            if (e.transcript == null || e.transcript.trim().isEmpty()) continue;
            ctx.append("[").append(e.created != null ? e.created : "?").append("] ")
               .append(e.transcript.trim()).append("\n");
        }
        if (ctx.length() == 0) return "За последние 24 часа готовых записей нет.";

        String nano = GeminiNanoEngine.hourlyReport24h(app, ctx.toString());
        if (nano != null && nano.trim().length() >= 10) return nano.trim();
        // Fallback without GGUF editor: structured heuristic summary
        return qwenEngine.summarizePeriod(ctx.toString(), "последние 24 часа");
    }

    public String answer(String question, String context) {
        // 1) System Gemini Nano
        try {
            String nano = GeminiNanoEngine.answer(app, question, context);
            if (nano != null && !nano.trim().isEmpty()) return nano.trim();
        } catch (Throwable ignored) {}
        // 2) Optional local GGUF only for Q&A if user installed it
        try {
            if (LlmEngine.available() && ModelManager.installed(app, ModelManager.LLM)) {
                String prompt = QwenEngine.buildLlmPrompt(question, context);
                String out = LlmEngine.generate(app, prompt, 320, 0.3f);
                if (out != null && !out.startsWith("LLM-") && !out.trim().isEmpty()) {
                    return out.trim();
                }
            }
        } catch (Throwable ignored) {}
        // 3) Template engine
        return qwenEngine.answerQuestion(question, context);
    }

    public QwenEngine.DaySummary summarizeDay(List<Entry> entries, String date) {
        return qwenEngine.buildStructuredSummary(entries, date);
    }

    public String neuralDayBrief(List<Entry> entries, String date) {
        if (!qwenReady() || !LlmEngine.available()) return "";
        return qwenEngine.neuralDayBrief(entries, date);
    }

    public String summarize(String context, String date) {
        return qwenEngine.summarizePeriod(context, date);
    }

    public String summarize(String context) {
        return summarize(context, null);
    }

    public String transcribeRealtimePcm(float[] pcm) {
        if (pcm == null || pcm.length == 0) return "";
        ensureNative();
        if (!whisperLoaded || !ModelManager.installed(app, ModelManager.WHISPER)) return "";
        try {
            File model = ModelManager.file(app, ModelManager.WHISPER);
            return nativeTranscribeRealtimePcm(pcm, model.getAbsolutePath());
        } catch (Throwable ignored) {
            return "";
        }
    }

    private native String nativeTranscribePcm(float[] pcm, String whisperModel);
    private static native String nativeTranscribeRealtimePcm(float[] pcm, String whisperModel);
}
