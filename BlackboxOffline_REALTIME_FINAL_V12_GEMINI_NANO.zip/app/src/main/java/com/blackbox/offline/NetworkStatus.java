package com.blackbox.offline;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;

/** Lightweight online check — no INTERNET permission required for status, only capability. */
public final class NetworkStatus {
    private NetworkStatus() {}

    public static boolean isOnline(Context c) {
        try {
            ConnectivityManager cm = (ConnectivityManager)
                    c.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            if (Build.VERSION.SDK_INT >= 23) {
                Network n = cm.getActiveNetwork();
                if (n == null) return false;
                NetworkCapabilities caps = cm.getNetworkCapabilities(n);
                if (caps == null) return false;
                return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        && (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                            || caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                            || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                            || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
            }
            @SuppressWarnings("deprecation")
            android.net.NetworkInfo ni = cm.getActiveNetworkInfo();
            return ni != null && ni.isConnected();
        } catch (Throwable t) {
            return false;
        }
    }

    public static String label(Context c) {
        return isOnline(c) ? "Сеть · online" : "Сеть · offline";
    }

    public static String shortLabel(Context c) {
        return isOnline(c) ? "online" : "offline";
    }
}
