package com.blackbox.offline;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;
import java.io.*;
import java.text.*;
import java.util.*;

/**
 * Foreground local microphone service with:
 * - Smart Audio Gate: completely suppresses capture while phone plays media (YouTube, music, app player, ringtones)
 * - Robust Dual-Stage VAD (Energy + ZCR + Attack Confirmation)
 * - Hands-free Voice Recall: answers queries like "блэкбокс, какой код..." via instant push notification
 */
public class RecordingService extends Service {
    public static final String START = "com.blackbox.offline.START_RECORDING";
    public static final String STOP = "com.blackbox.offline.STOP_RECORDING";
    public static final String DUCK_MEDIA = "com.blackbox.offline.DUCK_MEDIA";
    public static final String RESTORE_MEDIA = "com.blackbox.offline.RESTORE_MEDIA";
    public static final String EMERGENCY_WIPE = "com.blackbox.offline.EMERGENCY_WIPE";
    public static final String STATE = "com.blackbox.offline.RECORDING_STATE";
    public static final String ENTRIES = "com.blackbox.offline.ENTRIES";
    public static final String AUDIO_STATE = "com.blackbox.offline.AUDIO_STATE";

    static final int RATE = 16000;
    static final int FRAME = 1024;
    static final long QUIET_TIMEOUT_MS = 1500;
    // Было 600000 (10 минут) — при более мягком VAD-старте это позволяло
    // клипу растягиваться на несколько минут фонового шума, что и вызывало
    // длинные галлюцинации Whisper («We We We We…»). 90 сек хватает на
    // длинную реплику, но отсекает бесконтрольный рост клипа.
    static final long MAX_CLIP_MS = 90000;

    // Было: 600 / 2.7 / 5 / [12,200] — слишком строго для тихой речи и части микрофонов.
    // Понижено, чтобы VAD чаще пропускал реальную речь. Крутите эти 5 констант,
    // если через logcat (тег BlackboxVAD) увидите, что ваш currentRms/zcr
    // не дотягивает до порога даже при явной речи.
    private static final double MIN_VOICE_RMS = 350.0;
    private static final double NOISE_ADAPT_ALPHA = 0.05;
    private static final double VAD_SNR_RATIO = 2.0;
    private static final int MIN_CONSECUTIVE_VOICED = 3;
    private static final int PRE_ROLL_FRAMES = 4;
    private static final int ZCR_MIN = 6;
    private static final int ZCR_MAX = 260;

    // Оригинальные, более строгие пороги — только для УДЕРЖАНИЯ уже
    // открытого клипа (см. isVoicedSustain ниже). Начать клип может тихая
    // речь, но чтобы его ПРОДОЛЖАТЬ, сигнал должен быть увереннее фонового
    // шума — иначе гул/шум не даёт клипу закрыться по тишине.
    private static final double SUSTAIN_MIN_VOICE_RMS = 600.0;
    private static final double SUSTAIN_VAD_SNR_RATIO = 2.7;
    private static final int SUSTAIN_ZCR_MIN = 12;
    private static final int SUSTAIN_ZCR_MAX = 200;

    private static final String TAG_VAD = "BlackboxVAD";
    private long lastVadLogMs = 0;

    public static volatile boolean isRecordingActive = false;
    public static volatile boolean isAppPlayingAudio = false;

    private double noiseFloor = 350.0;
    private AudioRecord mic;
    private Thread worker;
    private volatile boolean active;
    private volatile boolean saving;
    private ByteArrayOutputStream clip;
    private long began;
    // Время последнего уверенного голосового фрейма текущего клипа.
    // Нужно для корректного закрытия записи после QUIET_TIMEOUT_MS тишины.
    private long lastVoiceTime = 0L;
    private Entry liveEntry;
    private RealtimeTranscriber realtimeTranscriber;
    private VoskEngine mediaCommandVosk;
    private long lastMediaCommandAt = 0L;
    private String lastMediaCommandText = "";
    public static volatile boolean speakerMediaActive = false;
    public static volatile boolean mediaDucked = false;
    public static volatile long mediaDuckUntil = 0L;
    private AudioManager audioManager;
    private AudioFocusRequest audioFocusRequest;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Runnable mediaDuckTimeout = this::releaseMediaDuck;
    private long lastAudioStateBroadcastAt = 0L;

    private int totalFramesInClip = 0;
    private int voicedFramesInClip = 0;

    private final byte[][] preRoll = new byte[PRE_ROLL_FRAMES][FRAME * 2];
    private int preRollIndex = 0;
    private int preRollCount = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        // Подогрев whisper в фоне — записи расшифровываются мгновенно
        new Thread(() -> LocalAiEngine.warm(this), "blackbox-whisper-warm").start();
        realtimeTranscriber = new RealtimeTranscriber(this);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("rec", "Чёрный ящик · запись", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Автономная фоновая запись");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                nm.createNotificationChannel(ch);

                // Notification channel for instant voice recall ("Чёрный ящик, напомни...")
                NotificationChannel memoryCh = new NotificationChannel("memory_recall", "Чёрный ящик · Память", NotificationManager.IMPORTANCE_HIGH);
                memoryCh.setDescription("Голосовые ответы памяти «Чёрный ящик»");
                memoryCh.enableVibration(true);
                nm.createNotificationChannel(memoryCh);
            }
        }
    }

    @Override
    public int onStartCommand(Intent i, int f, int id) {
        String action = i == null ? "" : i.getAction();
        if (START.equals(action) && !active) start();
        if (STOP.equals(action)) stop();
        if (DUCK_MEDIA.equals(action)) requestMediaDuck();
        if (RESTORE_MEDIA.equals(action)) releaseMediaDuck();
        if (EMERGENCY_WIPE.equals(action)) emergencyWipe();
        return START_NOT_STICKY;
    }

    void start() {
        try {
            Intent si = new Intent(this, RecordingService.class).setAction(STOP);
            PendingIntent pi = PendingIntent.getService(this, 1, si, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(this, "rec")
                    .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                    .setContentTitle("Чёрный ящик")
                    .setContentText("Фоновое прослушивание активно · «Чёрный ящик, стоп»")
                    .setOngoing(true)
                    .addAction(new Notification.Action.Builder(null, "Остановить", pi).build())
                    .build();

            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(701, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(701, n);
            }

            int b = Math.max(AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), FRAME * 4);
            mic = new AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, b);
            mic.startRecording();
            active = true;
            state(true);

            worker = new Thread(this::loop);
            worker.start();
        } catch (Exception x) {
            stop();
        }
    }

    private boolean isSpeakerMediaPlaying() {
        if (isAppPlayingAudio) return true;
        try {
            AudioManager am = audioManager != null ? audioManager : (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am == null) return false;
            int mode = am.getMode();
            if (mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION) return false;
            if (hasPrivateAudioOutput(am)) return false;
            return am.isMusicActive();
        } catch (Throwable ignored) {
            return false;
        }
    }

    private boolean isDevicePlayingAudio() {
        if (isAppPlayingAudio) return true;
        try {
            AudioManager am = audioManager != null ? audioManager : (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                int mode = am.getMode();
                if (mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION) return true;
                if (hasPrivateAudioOutput(am)) return false;
                if (am.isMusicActive()) return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    private void broadcastAudioState(boolean force) {
        long now = System.currentTimeMillis();
        if (!force && now - lastAudioStateBroadcastAt < 250) return;
        lastAudioStateBroadcastAt = now;
        try {
            Intent i = new Intent(AUDIO_STATE).setPackage(getPackageName());
            i.putExtra("speaker_media", speakerMediaActive);
            i.putExtra("ducked", mediaDucked);
            i.putExtra("duck_until", mediaDuckUntil);
            sendBroadcast(i);
        } catch (Throwable ignored) {}
    }

    private void emergencyWipe() {
        // Stop all capture/transcription resources before touching local files.
        try { active = false; } catch (Throwable ignored) {}
        try { if (realtimeTranscriber != null) realtimeTranscriber.stop(); } catch (Throwable ignored) {}
        try { if (mediaCommandVosk != null) mediaCommandVosk.release(); } catch (Throwable ignored) {}
        mediaCommandVosk = null;
        try { mainHandler.removeCallbacksAndMessages(null); } catch (Throwable ignored) {}
        try { releaseMediaDuck(); } catch (Throwable ignored) {}
        try { if (mic != null) { mic.stop(); mic.release(); } } catch (Throwable ignored) {}
        mic = null;
        try { stopForeground(true); } catch (Throwable ignored) {}
        isRecordingActive = false;
        speakerMediaActive = false;
        mediaDucked = false;
        mediaDuckUntil = 0L;
        try { EmergencySecurity.wipe(this); } catch (Throwable ignored) {}
        stopSelf();
        // Do not leave an active process with stale objects after an emergency wipe.
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            try { android.os.Process.killProcess(android.os.Process.myPid()); } catch (Throwable ignored) {}
        }, 180L);
    }

    private void requestMediaDuck() {
        try {
            if (audioManager == null) audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (audioManager == null) return;
            int result;
            if (Build.VERSION.SDK_INT >= 26) {
                if (audioFocusRequest == null) {
                    AudioAttributes attrs = new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build();
                    audioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                            .setAudioAttributes(attrs)
                            .setWillPauseWhenDucked(false)
                            .build();
                }
                result = audioManager.requestAudioFocus(audioFocusRequest);
            } else {
                @SuppressWarnings("deprecation")
                int legacyResult = audioManager.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK);
                result = legacyResult;
            }
            if (result != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) return;
            mediaDucked = true;
            mediaDuckUntil = System.currentTimeMillis() + 10 * 60 * 1000L;
            mainHandler.removeCallbacks(mediaDuckTimeout);
            mainHandler.postDelayed(mediaDuckTimeout, 10 * 60 * 1000L);
            broadcastAudioState(true);
        } catch (Throwable ignored) {}
    }

    private void releaseMediaDuck() {
        try {
            if (audioManager != null) {
                if (Build.VERSION.SDK_INT >= 26 && audioFocusRequest != null) {
                    audioManager.abandonAudioFocusRequest(audioFocusRequest);
                } else {
                    @SuppressWarnings("deprecation")
                    int ignored = audioManager.abandonAudioFocus(null);
                }
            }
        } catch (Throwable ignored) {}
        mediaDucked = false;
        mediaDuckUntil = 0L;
        broadcastAudioState(true);
    }

    private void checkMediaCommand(short[] f, int n) {
        if (f == null || n <= 0) return;
        try {
            if (mediaCommandVosk == null) mediaCommandVosk = new VoskEngine(this);
            if (!mediaCommandVosk.isReady()) return;
            String hyp = mediaCommandVosk.accept(f, n);
            if (hyp == null || hyp.trim().isEmpty()) return;
            String clean = AutoTranscriber.cleanHallucinations(hyp).trim();
            if (clean.isEmpty()) return;
            long now = System.currentTimeMillis();
            if (now - lastMediaCommandAt < 4000 && clean.equalsIgnoreCase(lastMediaCommandText)) return;
            if (EmergencySecurity.matches(this, clean)) {
                lastMediaCommandAt = now;
                lastMediaCommandText = clean;
                mediaCommandVosk.reset();
                emergencyWipe();
                return;
            } else if (AutoTranscriber.looksLikeMediaDuckCommand(clean)) {
                lastMediaCommandAt = now;
                lastMediaCommandText = clean;
                mediaCommandVosk.reset();
                requestMediaDuck();
            } else if (AutoTranscriber.looksLikeMediaRestoreCommand(clean)) {
                lastMediaCommandAt = now;
                lastMediaCommandText = clean;
                mediaCommandVosk.reset();
                releaseMediaDuck();
            } else if (AutoTranscriber.isStopCommandText(clean.toLowerCase(Locale.ROOT))) {
                lastMediaCommandAt = now;
                lastMediaCommandText = clean;
                mediaCommandVosk.reset();
                try { startService(new Intent(this, RecordingService.class).setAction(STOP)); } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
    }

    /** true, если аудио уходит в наушники/гарнитуру, а не в динамик. */
    private boolean hasPrivateAudioOutput(AudioManager am) {
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                for (AudioDeviceInfo d : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                    int t = d.getType();
                    if (t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES
                            || t == AudioDeviceInfo.TYPE_WIRED_HEADSET
                            || t == AudioDeviceInfo.TYPE_USB_HEADSET
                            || t == AudioDeviceInfo.TYPE_BLE_HEADSET
                            || t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP
                            || t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO) {
                        return true;
                    }
                }
                return false;
            } else {
                @SuppressWarnings("deprecation")
                boolean wired = am.isWiredHeadsetOn();
                @SuppressWarnings("deprecation")
                boolean bt = am.isBluetoothA2dpOn();
                return wired || bt;
            }
        } catch (Throwable ignored) {
            return false; // не уверены — старое поведение (глушить)
        }
    }

    void loop() {
        short[] f = new short[FRAME];
        byte[] frameBytes = new byte[FRAME * 2];
        int consecutiveVoiced = 0;

        while (active) {
            boolean speakerMedia = isSpeakerMediaPlaying();
            if (speakerMedia != speakerMediaActive) {
                speakerMediaActive = speakerMedia;
                broadcastAudioState(true);
            }

            int n = mic != null ? mic.read(f, 0, FRAME) : -1;
            if (n <= 0) continue;

            // Пока динамик занят медиа, не сохраняем и не показываем медиа как речь,
            // но продолжаем короткий command-only Vosk путь: голосовые команды
            // («Блэкбокс, отключи микрофон», «приглуши музыку») должны срабатывать.
            if (speakerMediaActive) {
                if (saving) abortCurrentClip();
                consecutiveVoiced = 0;
                checkMediaCommand(f, n);
                try { Thread.sleep(20); } catch (InterruptedException ignored) {}
                continue;
            }

            long sumSq = 0;
            int zcr = 0;
            for (int i = 0; i < n; i++) {
                short val = f[i];
                sumSq += (long) val * val;
                frameBytes[i * 2] = (byte) (val & 255);
                frameBytes[i * 2 + 1] = (byte) ((val >> 8) & 255);
                if (i > 0 && ((f[i] >= 0 && f[i - 1] < 0) || (f[i] < 0 && f[i - 1] >= 0))) {
                    zcr++;
                }
            }

            double currentRms = Math.sqrt(sumSq / (double) n);

            if (!saving && currentRms < noiseFloor * 1.5) {
                noiseFloor = (1.0 - NOISE_ADAPT_ALPHA) * noiseFloor + NOISE_ADAPT_ALPHA * currentRms;
                if (noiseFloor < 120.0) noiseFloor = 120.0;
            }

            double requiredThreshold = Math.max(MIN_VOICE_RMS, noiseFloor * VAD_SNR_RATIO);
            boolean isVoiced = (currentRms >= requiredThreshold) && (zcr >= ZCR_MIN && zcr <= ZCR_MAX);
            // Отдельный, более строгий порог для УДЕРЖАНИЯ уже открытого клипа
            // (обновление lastVoiceTime). Мягкий isVoiced выше нужен только
            // чтобы НАЧАТЬ запись при тихой речи — но если тем же мягким
            // порогом ещё и продлевать клип, фоновый шум/гул то и дело
            // пересекает его и не даёт клипу закрыться по тишине, из-за чего
            // Whisper получает многоминутные куски с шумом и начинает
            // галлюцинировать (повторы слов, случайные фразы). Для удержания
            // используем оригинальные, более строгие цифры.
            boolean isVoicedSustain = (currentRms >= Math.max(SUSTAIN_MIN_VOICE_RMS, noiseFloor * SUSTAIN_VAD_SNR_RATIO))
                    && (zcr >= SUSTAIN_ZCR_MIN && zcr <= SUSTAIN_ZCR_MAX);

            long now = System.currentTimeMillis();

            // Раз в секунду печатаем реальные цифры в logcat, чтобы можно было
            // подобрать пороги под конкретный микрофон: adb logcat -s BlackboxVAD
            if (now - lastVadLogMs >= 1000) {
                lastVadLogMs = now;
                android.util.Log.d(TAG_VAD, String.format(java.util.Locale.US,
                        "rms=%.0f threshold=%.0f noiseFloor=%.0f zcr=%d voiced=%b sustain=%b saving=%b",
                        currentRms, requiredThreshold, noiseFloor, zcr, isVoiced, isVoicedSustain, saving));
            }

            if (!saving) {
                System.arraycopy(frameBytes, 0, preRoll[preRollIndex], 0, frameBytes.length);
                preRollIndex = (preRollIndex + 1) % PRE_ROLL_FRAMES;
                if (preRollCount < PRE_ROLL_FRAMES) preRollCount++;

                if (isVoiced) {
                    consecutiveVoiced++;
                    if (consecutiveVoiced >= MIN_CONSECUTIVE_VOICED) {
                        saving = true;
                        clip = new ByteArrayOutputStream();
                        began = lastVoiceTime = now;
                        totalFramesInClip = 0;
                        voicedFramesInClip = consecutiveVoiced;

                        String id = UUID.randomUUID().toString();
                        String timeStr = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());
                        liveEntry = new Entry(id, "", timeStr, 0, "", "", "Заметки");
                        liveEntry.status = "Обработка…";
                        new EntryStore(this).add(liveEntry);
                        if (realtimeTranscriber != null) realtimeTranscriber.start(liveEntry);

                        int startIdx = (preRollIndex - preRollCount + PRE_ROLL_FRAMES) % PRE_ROLL_FRAMES;
                        for (int i = 0; i < preRollCount; i++) {
                            int idx = (startIdx + i) % PRE_ROLL_FRAMES;
                            clip.write(preRoll[idx], 0, preRoll[idx].length);
                            totalFramesInClip++;
                        }
                        // Feed the pre-roll immediately so the first words are not lost.
                        if (realtimeTranscriber != null) {
                            short[] pre = new short[FRAME];
                            for (int i = 0; i < preRollCount; i++) {
                                int idx = (startIdx + i) % PRE_ROLL_FRAMES;
                                byte[] b = preRoll[idx];
                                for (int j = 0; j < FRAME; j++) pre[j] = (short)((b[j*2] & 255) | (b[j*2+1] << 8));
                                realtimeTranscriber.feed(pre, FRAME);
                            }
                        }
                        sendBroadcast(new Intent(ENTRIES).setPackage(getPackageName()));
                    }
                } else {
                    consecutiveVoiced = 0;
                }
            } else {
                totalFramesInClip++;
                if (isVoicedSustain) {
                    voicedFramesInClip++;
                    lastVoiceTime = now;
                }

                clip.write(frameBytes, 0, frameBytes.length);
                if (realtimeTranscriber != null) realtimeTranscriber.feed(f, n);

                if (totalFramesInClip >= 19 && voicedFramesInClip < 4) {
                    abortCurrentClip();
                    consecutiveVoiced = 0;
                    continue;
                }

                if (now - lastVoiceTime >= QUIET_TIMEOUT_MS || now - began >= MAX_CLIP_MS) {
                    close();
                    consecutiveVoiced = 0;
                }
            }
        }
    }

    private synchronized void abortCurrentClip() {
        saving = false;
        if (realtimeTranscriber != null) realtimeTranscriber.cancel();
        if (liveEntry != null) {
            try { new EntryStore(this).delete(liveEntry.id); } catch (Exception ignored) {}
            liveEntry = null;
        }
        clip = null;
        sendBroadcast(new Intent(ENTRIES).setPackage(getPackageName()));
    }

    synchronized void close() {
        if (!saving || clip == null) return;
        saving = false;
        if (realtimeTranscriber != null) realtimeTranscriber.finish();
        try {
            byte[] p = clip.toByteArray();
            clip = null;

            if (p.length < (int) (RATE * 1.5) || voicedFramesInClip < 8) {
                if (realtimeTranscriber != null) realtimeTranscriber.cancel();
                if (liveEntry != null) new EntryStore(this).delete(liveEntry.id);
                liveEntry = null;
                sendBroadcast(new Intent(ENTRIES).setPackage(getPackageName()));
                return;
            }

            File d = new File(getExternalFilesDir(null), "audio");
            d.mkdirs();
            String id = liveEntry != null ? liveEntry.id : UUID.randomUUID().toString();
            File out = new File(d, id + ".wav");
            wav(out, p);

            if (!out.isFile() || out.length() < 44 + p.length) {
                if (realtimeTranscriber != null) realtimeTranscriber.cancel();
                out.delete();
                if (liveEntry != null) new EntryStore(this).delete(liveEntry.id);
                liveEntry = null;
                sendBroadcast(new Intent(ENTRIES).setPackage(getPackageName()));
                return;
            }

            long durationSec = Math.max(1, p.length / (RATE * 2));
            Entry e = liveEntry;
            if (e == null) {
                String timeStr = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());
                e = new Entry(id, out.getPath(), timeStr, durationSec, "", "", "Заметки");
                new EntryStore(this).add(e);
            } else {
                e.path = out.getPath();
                e.duration = durationSec;
            }
            // Vosk is live-only. Final diary card always comes from Whisper Base on the WAV.
            e.transcript = "";
            e.status = "В очереди";
            new EntryStore(this).upsert(e);
            liveEntry = null;
            if (realtimeTranscriber != null) realtimeTranscriber.finish();
            AutoTranscriber.enqueue(this, e);
            sendBroadcast(new Intent(ENTRIES).setPackage(getPackageName()));
        } catch (Exception ignored) {
            if (liveEntry != null) {
                try { liveEntry.status = "Ошибка сохранения записи"; new EntryStore(this).replace(liveEntry); } catch (Exception ignored2) {}
            }
            liveEntry = null;
            sendBroadcast(new Intent(ENTRIES).setPackage(getPackageName()));
        }
    }

    void wav(File f, byte[] p) throws Exception {
        try (FileOutputStream o = new FileOutputStream(f)) {
            o.write("RIFF".getBytes());
            le(o, 36 + p.length);
            o.write("WAVEfmt ".getBytes());
            le(o, 16);
            o.write(new byte[]{1, 0, 1, 0});
            le(o, RATE);
            le(o, RATE * 2);
            o.write(new byte[]{2, 0, 16, 0});
            o.write("data".getBytes());
            le(o, p.length);
            o.write(p);
            o.flush();
        }
    }

    void le(OutputStream o, int n) throws Exception {
        o.write(n);
        o.write(n >> 8);
        o.write(n >> 16);
        o.write(n >> 24);
    }

    void stop() {
        if (active && saving) close();
        active = false;
        if (realtimeTranscriber != null) realtimeTranscriber.stop();
        if (mediaCommandVosk != null) { try { mediaCommandVosk.release(); } catch (Throwable ignored) {} mediaCommandVosk = null; }
        mainHandler.removeCallbacks(mediaDuckTimeout);
        releaseMediaDuck();
        speakerMediaActive = false;
        broadcastAudioState(true);
        state(false);
        try {
            if (mic != null) {
                mic.stop();
                mic.release();
                mic = null;
            }
        } catch (Exception ignored) {}
        stopForeground(true);
        stopSelf();
    }

    void state(boolean x) {
        isRecordingActive = x;
        AutoTranscriber.notifyRecordingStateChanged();
        sendBroadcast(new Intent(STATE).setPackage(getPackageName()).putExtra("active", x));
        try {
            BlackboxWidgetProvider.updateAllWidgets(this, x);
            BlackboxSquareWidgetProvider.updateAllSquareWidgets(this, x);
        } catch (Throwable ignored) {}
    }

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public void onDestroy() {
        if (active) stop();
        super.onDestroy();
    }
}
