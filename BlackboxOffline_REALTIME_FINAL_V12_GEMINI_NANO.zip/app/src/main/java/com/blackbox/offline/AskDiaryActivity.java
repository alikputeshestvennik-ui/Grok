package com.blackbox.offline;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.*;
import android.view.View;
import java.util.*;

public class AskDiaryActivity extends Activity {
    private EditText queryInput;
    private TextView resultText;
    private Button copyBtn;
    private String searchOutput = "";
    private LocalAiEngine aiEngine;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        aiEngine = new LocalAiEngine(this);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(UI.COLOR_BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int padH = UI.dp(this, 18);
        int padV = UI.dp(this, 20);
        root.setPadding(padH, padV, padH, padV);

        // Studio Header
        root.addView(UI.createHeader(this, "Спросить дневник", "Семантический ответ и поиск по смыслу", true));

        // Search Input Card
        LinearLayout searchCard = UI.createCard(this);

        TextView labelSearch = new TextView(this);
        labelSearch.setText("ВАШ ВОПРОС К ДНЕВНИКУ");
        labelSearch.setTextColor(UI.COLOR_TEXT_SUBTLE);
        labelSearch.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        labelSearch.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        labelSearch.setLetterSpacing(0.06f);
        labelSearch.setPadding(0, 0, 0, UI.dp(this, 8));
        searchCard.addView(labelSearch);

        queryInput = UI.inputField(this, "Например: О чём мы договорились на встрече?");
        searchCard.addView(queryInput);

        // Suggested intent chips
        LinearLayout suggestionsRow = new LinearLayout(this);
        suggestionsRow.setOrientation(LinearLayout.HORIZONTAL);
        suggestionsRow.setPadding(0, UI.dp(this, 10), 0, 0);

        Button chipTasks = createSuggestChip("📌 Мои задачи");
        chipTasks.setOnClickListener(v -> {
            queryInput.setText("Какие задачи и дела запланированы?");
            askDiary();
        });
        suggestionsRow.addView(chipTasks);

        Button chipMeetings = createSuggestChip("🤝 Встречи");
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(-2, -2);
        mlp.leftMargin = UI.dp(this, 8);
        chipMeetings.setOnClickListener(v -> {
            queryInput.setText("О чём мы говорили на встречах и созвонах?");
            askDiary();
        });
        suggestionsRow.addView(chipMeetings, mlp);

        Button chipFocus = createSuggestChip("🎯 Главное");
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(-2, -2);
        flp.leftMargin = UI.dp(this, 8);
        chipFocus.setOnClickListener(v -> {
            queryInput.setText("Каковы ключевые приоритеты?");
            askDiary();
        });
        suggestionsRow.addView(chipFocus, flp);

        searchCard.addView(suggestionsRow);

        Button searchBtn = UI.primaryButton(this, "✨ Найти ответ в архиве");
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(-1, -2);
        btnLp.topMargin = UI.dp(this, 14);
        searchBtn.setOnClickListener(v -> askDiary());
        searchCard.addView(searchBtn, btnLp);

        LinearLayout.LayoutParams scLp = new LinearLayout.LayoutParams(-1, -2);
        scLp.bottomMargin = UI.dp(this, 16);
        root.addView(searchCard, scLp);

        // Results Card
        LinearLayout resCard = UI.createCard(this);

        LinearLayout headRow = new LinearLayout(this);
        headRow.setOrientation(LinearLayout.HORIZONTAL);
        headRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView resLabel = new TextView(this);
        resLabel.setText("✨ ОТВЕТ AI-СИНТЕЗАТОРА");
        resLabel.setTextColor(UI.COLOR_TEXT_ORANGE);
        resLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        resLabel.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        headRow.addView(resLabel);

        View sp = new View(this);
        headRow.addView(sp, new LinearLayout.LayoutParams(0, 1, 1.0f));

        copyBtn = UI.secondaryButton(this, "Скопировать");
        copyBtn.setVisibility(Button.GONE);
        copyBtn.setOnClickListener(v -> {
            if (!searchOutput.isEmpty()) {
                UI.copyToClipboard(this, "Ответ дневника", searchOutput);
            }
        });
        headRow.addView(copyBtn);

        resCard.addView(headRow);

        resultText = new TextView(this);
        resultText.setText("Задайте любой вопрос по событиям, задачам, встречам или идеям из ваших аудиозаписей — AI синтезирует точный ответ.");
        resultText.setTextColor(UI.COLOR_TEXT_MUTED);
        resultText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        resultText.setLineSpacing(UI.dp(this, 4), 1.0f);
        resultText.setPadding(0, UI.dp(this, 12), 0, 0);
        resCard.addView(resultText);

        root.addView(resCard);

        scroll.addView(root);
        setContentView(scroll);
    }

    private Button createSuggestChip(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        b.setAllCaps(false);
        b.setTextColor(UI.COLOR_TEXT_MUTED);
        b.setBackground(UI.buttonRipple(UI.shape(0xFF161A22, UI.COLOR_BORDER, 8, this), 0x33F47721));
        int padH = UI.dp(this, 10);
        int padV = UI.dp(this, 4);
        b.setPadding(padH, padV, padH, padV);
        return b;
    }

    private void askDiary() {
        String question = queryInput.getText().toString().trim();
        if (question.isEmpty()) {
            resultText.setText("Введите вопрос для анализа.");
            resultText.setTextColor(UI.COLOR_TEXT_MUTED);
            copyBtn.setVisibility(Button.GONE);
            return;
        }

        StringBuilder contextBuilder = new StringBuilder();
        int count = 0;
        for (Entry e : new EntryStore(this).all()) {
            if (e.transcript != null && !e.transcript.trim().isEmpty()) {
                count++;
                contextBuilder.append("[").append(e.created).append("] ")
                              .append(e.important ? "★ ВАЖНО: " : "")
                              .append(e.transcript.trim())
                              .append("\n\n");
            }
        }

        if (count == 0) {
            searchOutput = "";
            resultText.setText("В дневнике пока нет расшифрованных записей для анализа.");
            resultText.setTextColor(UI.COLOR_TEXT_MUTED);
            copyBtn.setVisibility(Button.GONE);
        } else {
            searchOutput = "";
            resultText.setText("Думаю…\nЛокальная нейросеть работает, первый ответ может занять до минуты.");
            resultText.setTextColor(UI.COLOR_TEXT_MUTED);
            copyBtn.setVisibility(Button.GONE);
            final String ctx = contextBuilder.toString();
            final String q = question;
            new Thread(() -> {
                final String out = aiEngine.answer(q, ctx);
                runOnUiThread(() -> {
                    searchOutput = out;
                    resultText.setText(out);
                    resultText.setTextColor(UI.COLOR_TEXT_PRIMARY);
                    copyBtn.setVisibility(Button.VISIBLE);
                });
            }).start();
        }
    }
}
