package com.blackbox.offline;
import android.content.*;import org.json.*;import java.util.*;
public class EntryStore {
 private final SharedPreferences p; private static final String KEY="entries_v2";
 private static final Object LOCK=new Object();
 EntryStore(Context c){p=c.getSharedPreferences("blackbox_local",Context.MODE_PRIVATE);}
 ArrayList<Entry> all(){synchronized(LOCK){ArrayList<Entry>r=new ArrayList<>();try{JSONArray a=new JSONArray(p.getString(KEY,"[]"));for(int i=0;i<a.length();i++)r.add(Entry.from(a.getJSONObject(i)));}catch(Exception x){}return r;}}
 void save(ArrayList<Entry>a){synchronized(LOCK){try{JSONArray x=new JSONArray();for(Entry e:a)x.put(e.json());p.edit().putString(KEY,x.toString()).apply();}catch(Exception x){}}}
 void add(Entry e){synchronized(LOCK){ArrayList<Entry>a=allLocked();a.add(0,e);saveLocked(a);}}
 void replace(Entry e){synchronized(LOCK){ArrayList<Entry>a=allLocked();for(int i=0;i<a.size();i++)if(a.get(i).id.equals(e.id)){a.set(i,e);saveLocked(a);return;}}}
 void upsert(Entry e){synchronized(LOCK){ArrayList<Entry>a=allLocked();for(int i=0;i<a.size();i++)if(a.get(i).id.equals(e.id)){a.set(i,e);saveLocked(a);return;}a.add(0,e);saveLocked(a);}}
 void delete(String id){synchronized(LOCK){ArrayList<Entry>a=allLocked();for(Iterator<Entry>i=a.iterator();i.hasNext();)if(i.next().id.equals(id))i.remove();saveLocked(a);}}
 private ArrayList<Entry> allLocked(){ArrayList<Entry>r=new ArrayList<>();try{JSONArray a=new JSONArray(p.getString(KEY,"[]"));for(int i=0;i<a.length();i++)r.add(Entry.from(a.getJSONObject(i)));}catch(Exception x){}return r;}
 private void saveLocked(ArrayList<Entry>a){try{JSONArray x=new JSONArray();for(Entry e:a)x.put(e.json());p.edit().putString(KEY,x.toString()).apply();}catch(Exception x){}}
}
