package com.blackbox.offline;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.genai.common.DownloadCallback;
import com.google.mlkit.genai.common.FeatureStatus;
import com.google.mlkit.genai.common.GenAiException;
import com.google.mlkit.genai.prompt.GenerateContentRequest;
import com.google.mlkit.genai.prompt.GenerateContentResponse;
import com.google.mlkit.genai.prompt.Generation;
import com.google.mlkit.genai.prompt.TextPart;
import com.google.mlkit.genai.prompt.java.GenerativeModelFutures;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * ML Kit GenAI Prompt API → Gemini Nano via AICore.
 * All blocking ML Kit calls run only on a background executor — never on the UI thread.
 */
public final class GeminiNanoEngine {

    private static final String TAG = "GeminiNano";
    private static final String AICORE_PKG = "com.google.android.aicore";

    public static final String EDITOR_PROMPT =
            "Ты профессиональный редактор. Твоя задача — взять расшифровку устной речи, "
            + "исправить ошибки ASR-распознавания, убрать слова-паразиты, сгладить заикания "
            + "и оформить текст в читаемый вид с правильной пунктуацией, сохраняя исходный смысл. "
            + "Выдавай только готовый текст без пояснений.";

    private static final ExecutorService BG = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "gemini-nano-bg");
        t.setPriority(Thread.NORM_PRIORITY - 1);
        return t;
    });

    private static volatile Boolean sdkPresentCache = null;
    /** Cached FeatureStatus; null = not checked yet. */
    private static volatile Integer cachedStatus = null;
    private static volatile long cachedStatusAt = 0L;
    private static volatile boolean refreshInFlight = false;
    private static final Object GEN_LOCK = new Object();

    private GeminiNanoEngine() {}

    public static boolean isSdkPresent() {
        if (sdkPresentCache != null) return sdkPresentCache;
        try {
            Class.forName("com.google.mlkit.genai.prompt.Generation");
            Class.forName("com.google.mlkit.genai.prompt.java.GenerativeModelFutures");
            sdkPresentCache = true;
        } catch (Throwable t) {
            sdkPresentCache = false;
        }
        return sdkPresentCache;
    }

    /**
     * Non-blocking. Uses cache. Triggers background refresh if stale.
     * Safe on UI thread — never blocks.
     */
    public static boolean isAvailable(Context c) {
        if (!isSdkPresent()) return false;
        Integer s = cachedStatus;
        if (s == null || System.currentTimeMillis() - cachedStatusAt > 60_000L) {
            refreshStatusAsync(c);
        }
        return s != null && s == FeatureStatus.AVAILABLE;
    }

    /** Kick off status check on background thread. Safe from UI. */
    public static void refreshStatusAsync(Context c) {
        if (!isSdkPresent() || c == null) return;
        if (refreshInFlight) return;
        final Context app = c.getApplicationContext();
        refreshInFlight = true;
        BG.execute(() -> {
            try {
                int status = checkStatusBlocking();
                cachedStatus = status;
                cachedStatusAt = System.currentTimeMillis();
                Log.i(TAG, "FeatureStatus cached=" + statusToString(status));
            } catch (Throwable t) {
                Log.w(TAG, "status refresh failed: " + t.getMessage());
                cachedStatus = FeatureStatus.UNAVAILABLE;
                cachedStatusAt = System.currentTimeMillis();
            } finally {
                refreshInFlight = false;
            }
        });
    }

    public static boolean deviceLikelyHasGalaxyAi(Context c) {
        try {
            String m = Build.MODEL != null ? Build.MODEL.toLowerCase(Locale.US) : "";
            String man = Build.MANUFACTURER != null ? Build.MANUFACTURER.toLowerCase(Locale.US) : "";
            if (man.contains("google") && (m.contains("pixel 8") || m.contains("pixel 9")
                    || m.contains("pixel 10") || m.contains("pixel fold"))) return true;
            if (man.contains("samsung") && (m.startsWith("sm-s9") || m.startsWith("sm-s8")
                    || m.startsWith("sm-f9") || m.startsWith("sm-f7") || m.startsWith("sm-f6")
                    || m.startsWith("sm-f5") || m.contains("sm-f766") || m.contains("sm-f761")
                    || m.contains("sm-f741") || m.contains("sm-f956") || m.contains("sm-f966")))
                return true;
        } catch (Throwable ignored) {}
        return false;
    }

    public static boolean isAicorePackageInstalled(Context c) {
        try {
            c.getApplicationContext().getPackageManager().getPackageInfo(AICORE_PKG, 0);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static GenerativeModelFutures client() {
        return GenerativeModelFutures.from(Generation.INSTANCE.getClient());
    }

    /** Blocking — call only from background threads. */
    private static int checkStatusBlocking() throws Exception {
        GenerativeModelFutures gm = client();
        Integer status = gm.checkStatus().get(12, TimeUnit.SECONDS);
        return status != null ? status : FeatureStatus.UNAVAILABLE;
    }

    private static String statusToString(int s) {
        if (s == FeatureStatus.AVAILABLE) return "AVAILABLE";
        if (s == FeatureStatus.DOWNLOADABLE) return "DOWNLOADABLE";
        if (s == FeatureStatus.DOWNLOADING) return "DOWNLOADING";
        return "UNAVAILABLE(" + s + ")";
    }

    /** Blocking download — background only. */
    public static boolean ensureDownloaded(Context c) {
        if (!isSdkPresent()) return false;
        try {
            GenerativeModelFutures gm = client();
            int status = checkStatusBlocking();
            cachedStatus = status;
            cachedStatusAt = System.currentTimeMillis();
            if (status == FeatureStatus.AVAILABLE) return true;
            if (status != FeatureStatus.DOWNLOADABLE && status != FeatureStatus.DOWNLOADING) {
                return false;
            }
            final AtomicReference<Throwable> fail = new AtomicReference<>();
            final Object done = new Object();
            final boolean[] completed = {false};
            gm.download(new DownloadCallback() {
                @Override public void onDownloadStarted(long bytesToDownload) {
                    Log.i(TAG, "Nano download started, bytes=" + bytesToDownload);
                }
                @Override public void onDownloadProgress(long bytesDownloaded) {
                    Log.d(TAG, "Nano download progress=" + bytesDownloaded);
                }
                @Override public void onDownloadCompleted() {
                    synchronized (done) {
                        completed[0] = true;
                        done.notifyAll();
                    }
                }
                @Override public void onDownloadFailed(GenAiException e) {
                    fail.set(e);
                    synchronized (done) {
                        completed[0] = true;
                        done.notifyAll();
                    }
                }
            });
            synchronized (done) {
                if (!completed[0]) done.wait(5 * 60 * 1000L);
            }
            if (fail.get() != null) {
                Log.e(TAG, "Nano download failed: " + fail.get().getMessage());
                return false;
            }
            int after = checkStatusBlocking();
            cachedStatus = after;
            cachedStatusAt = System.currentTimeMillis();
            return after == FeatureStatus.AVAILABLE;
        } catch (Throwable t) {
            Log.e(TAG, "ensureDownloaded: " + t.getMessage());
            return false;
        }
    }

    /** Blocking generate — must be called from background (AutoTranscriber / report threads). */
    public static String generate(Context c, String prompt, int maxOutputTokens) {
        if (prompt == null || prompt.trim().isEmpty()) return null;
        if (!isSdkPresent()) return null;
        if (Looper.myLooper() == Looper.getMainLooper()) {
            Log.e(TAG, "generate() called on main thread — refused to avoid ANR");
            return null;
        }
        synchronized (GEN_LOCK) {
            try {
                GenerativeModelFutures gm = client();
                int status = checkStatusBlocking();
                cachedStatus = status;
                cachedStatusAt = System.currentTimeMillis();
                if (status == FeatureStatus.DOWNLOADABLE) {
                    if (!ensureDownloaded(c)) return null;
                } else if (status != FeatureStatus.AVAILABLE) {
                    return null;
                }

                GenerateContentRequest.Builder b = new GenerateContentRequest.Builder(
                        new TextPart(prompt.trim()));
                try { b.getClass().getMethod("setTemperature", float.class).invoke(b, 0.2f); } catch (Throwable ignored) {}
                try {
                    b.getClass().getMethod("setMaxOutputTokens", int.class)
                            .invoke(b, Math.max(32, Math.min(maxOutputTokens, 1024)));
                } catch (Throwable ignored) {}
                GenerateContentRequest request = b.build();

                ListenableFuture<GenerateContentResponse> future = gm.generateContent(request);
                GenerateContentResponse response = future.get(90, TimeUnit.SECONDS);
                if (response == null) return null;
                String text = extractResponseText(response);
                if (text == null || text.trim().isEmpty()) return null;
                return text.trim();
            } catch (Throwable t) {
                Log.e(TAG, "generate failed: " + t.getMessage());
                return null;
            }
        }
    }

    private static String extractResponseText(GenerateContentResponse response) {
        if (response == null) return null;
        for (String method : new String[]{"getText", "getResult", "getOutputText"}) {
            try {
                Object v = response.getClass().getMethod(method).invoke(response);
                if (v instanceof String && !((String) v).trim().isEmpty()) {
                    return ((String) v).trim();
                }
            } catch (Throwable ignored) {}
        }
        try {
            Object candidates = response.getClass().getMethod("getCandidates").invoke(response);
            if (candidates instanceof java.util.List) {
                java.util.List<?> list = (java.util.List<?>) candidates;
                if (!list.isEmpty()) {
                    Object cand = list.get(0);
                    for (String method : new String[]{"getText", "getContent"}) {
                        try {
                            Object v = cand.getClass().getMethod(method).invoke(cand);
                            if (v instanceof String && !((String) v).trim().isEmpty()) {
                                return ((String) v).trim();
                            }
                            if (v != null && !(v instanceof String)) {
                                try {
                                    Object t = v.getClass().getMethod("getText").invoke(v);
                                    if (t instanceof String && !((String) t).trim().isEmpty()) {
                                        return ((String) t).trim();
                                    }
                                } catch (Throwable ignored) {}
                            }
                        } catch (Throwable ignored) {}
                    }
                }
            }
        } catch (Throwable ignored) {}
        return null;
    }

    public static String editTranscript(Context c, String rawAsr) {
        if (rawAsr == null || rawAsr.trim().isEmpty()) return null;
        String full = EDITOR_PROMPT + "\n\nТекст:\n" + rawAsr.trim();
        String out = generate(c, full, Math.max(96, Math.min(512, rawAsr.length() / 2 + 64)));
        if (out == null) return null;
        if (out.startsWith("Ты профессиональный") || out.contains("Выдавай только готовый")) return null;
        return out;
    }

    public static String hourlyReport24h(Context c, String archiveText) {
        if (archiveText == null || archiveText.trim().isEmpty()) return null;
        String prompt = "Ты аналитик. Сделай краткий пересказ всех записей за последние 24 часа, "
                + "сгруппировав по часам где возможно. Выдели ключевые темы, задачи и договорённости. "
                + "Выдай только готовый пересказ без пояснений.\n\n" + archiveText.trim();
        return generate(c, prompt, 512);
    }

    public static String shorten(Context c, String text) {
        if (text == null || text.trim().isEmpty()) return null;
        String prompt = "Сократи следующий текст до 2–4 коротких предложений, сохранив только ключевые факты и смысл. "
                + "Выдай только сокращённый текст без пояснений.\n\n" + text.trim();
        return generate(c, prompt, 160);
    }

    public static String answer(Context c, String question, String context) {
        if (question == null || question.trim().isEmpty()) return null;
        String prompt = "Ответь на вопрос пользователя, опираясь только на приведённый архив записей. "
                + "Если ответа нет в архиве — скажи об этом кратко. Без пояснений от себя.\n\n"
                + "Вопрос: " + question.trim() + "\n\nАрхив:\n"
                + (context == null ? "" : context);
        return generate(c, prompt, 320);
    }

    /** Non-blocking label for UI. */
    public static String statusLabel(Context c) {
        if (!isSdkPresent()) return "ML Kit GenAI · не в сборке";
        refreshStatusAsync(c);
        Integer s = cachedStatus;
        if (s == null) return "Gemini Nano · проверка…";
        if (s == FeatureStatus.AVAILABLE) return "Gemini Nano · готов";
        if (s == FeatureStatus.DOWNLOADABLE) return "Gemini Nano · можно скачать";
        if (s == FeatureStatus.DOWNLOADING) return "Gemini Nano · скачивается…";
        return "Gemini Nano · недоступен на устройстве";
    }

    /**
     * Non-blocking detailed status for Models tab.
     * Does NOT call ML Kit on the calling thread.
     */
    public static String detailedStatus(Context c) {
        refreshStatusAsync(c);
        StringBuilder sb = new StringBuilder();
        boolean pkg = isAicorePackageInstalled(c);
        boolean sdk = isSdkPresent();
        boolean likely = deviceLikelyHasGalaxyAi(c);
        String man = Build.MANUFACTURER != null ? Build.MANUFACTURER : "?";
        String model = Build.MODEL != null ? Build.MODEL : "?";

        Integer s = cachedStatus;
        String featureLine;
        if (!sdk) {
            featureLine = "SDK не в сборке";
        } else if (s == null) {
            featureLine = "проверка в фоне…";
        } else if (s == FeatureStatus.AVAILABLE) {
            featureLine = "AVAILABLE (готов к вызовам)";
        } else if (s == FeatureStatus.DOWNLOADABLE) {
            featureLine = "DOWNLOADABLE (нужна загрузка фичи)";
        } else if (s == FeatureStatus.DOWNLOADING) {
            featureLine = "DOWNLOADING";
        } else {
            featureLine = "UNAVAILABLE";
        }

        sb.append("ML Kit GenAI Prompt API (Gemini Nano)\n");
        sb.append("• SDK в APK: ").append(sdk ? "да" : "нет").append("\n");
        sb.append("• FeatureStatus: ").append(featureLine).append("\n");
        sb.append("• Пакет AICore: ").append(pkg ? "установлен" : "не найден").append("\n");
        sb.append("• Устройство: ").append(man).append(" · ").append(model).append("\n");
        sb.append("• Galaxy/Pixel hint: ").append(likely ? "да" : "нет").append("\n");
        boolean ready = s != null && s == FeatureStatus.AVAILABLE;
        sb.append("• Редактор ASR: ").append(ready ? "Gemini Nano" : "только Whisper").append("\n");
        sb.append("• Отчёты / поиск: ").append(ready ? "Gemini Nano" : "эвристика");
        return sb.toString();
    }
}
