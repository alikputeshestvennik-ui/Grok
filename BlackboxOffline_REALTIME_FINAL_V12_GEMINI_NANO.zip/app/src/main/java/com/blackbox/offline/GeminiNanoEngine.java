package com.blackbox.offline;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.genai.common.DownloadCallback;
import com.google.mlkit.genai.common.FeatureStatus;
import com.google.mlkit.genai.common.GenAiException;
import com.google.mlkit.genai.prompt.GenerateContentRequest;
import com.google.mlkit.genai.prompt.GenerateContentResponse;
import com.google.mlkit.genai.prompt.Generation;
import com.google.mlkit.genai.prompt.TextPart;
import com.google.mlkit.genai.prompt.java.GenerativeModelFutures;

import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * ML Kit GenAI Prompt API → Gemini Nano via Android AICore.
 *
 * On supported devices the system downloads / hosts Nano; the app only calls ML Kit.
 * If Nano / AICore is missing → methods return null and callers keep Whisper text.
 */
public final class GeminiNanoEngine {

    private static final String TAG = "GeminiNano";
    private static final String AICORE_PKG = "com.google.android.aicore";

    public static final String EDITOR_PROMPT =
            "Ты профессиональный редактор. Твоя задача — взять расшифровку устной речи, "
            + "исправить ошибки ASR-распознавания, убрать слова-паразиты, сгладить заикания "
            + "и оформить текст в читаемый вид с правильной пунктуацией, сохраняя исходный смысл. "
            + "Выдавай только готовый текст без пояснений.";

    private static volatile Boolean sdkPresentCache = null;
    private static final Object GEN_LOCK = new Object();

    private GeminiNanoEngine() {}

    public static boolean isSdkPresent() {
        if (sdkPresentCache != null) return sdkPresentCache;
        try {
            Class.forName("com.google.mlkit.genai.prompt.Generation");
            Class.forName("com.google.mlkit.genai.prompt.java.GenerativeModelFutures");
            sdkPresentCache = true;
        } catch (Throwable t) {
            sdkPresentCache = false;
        }
        return sdkPresentCache;
    }

    public static boolean isAvailable(Context c) {
        if (!isSdkPresent()) return false;
        try {
            int status = checkStatusBlocking(c);
            return status == FeatureStatus.AVAILABLE;
        } catch (Throwable t) {
            Log.w(TAG, "isAvailable: " + t.getMessage());
            return false;
        }
    }

    public static boolean deviceLikelyHasGalaxyAi(Context c) {
        try {
            String m = Build.MODEL != null ? Build.MODEL.toLowerCase(Locale.US) : "";
            String man = Build.MANUFACTURER != null ? Build.MANUFACTURER.toLowerCase(Locale.US) : "";
            if (man.contains("google") && (m.contains("pixel 8") || m.contains("pixel 9")
                    || m.contains("pixel 10") || m.contains("pixel fold"))) return true;
            if (man.contains("samsung") && (m.startsWith("sm-s9") || m.startsWith("sm-s8")
                    || m.startsWith("sm-f9") || m.startsWith("sm-f7") || m.startsWith("sm-f6")))
                return true;
        } catch (Throwable ignored) {}
        return false;
    }

    public static boolean isAicorePackageInstalled(Context c) {
        try {
            c.getApplicationContext().getPackageManager().getPackageInfo(AICORE_PKG, 0);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static GenerativeModelFutures client() {
        return GenerativeModelFutures.from(Generation.getClient());
    }

    public static int checkStatusBlocking(Context c) throws Exception {
        GenerativeModelFutures gm = client();
        Integer status = gm.checkStatus().get(20, TimeUnit.SECONDS);
        return status != null ? status : FeatureStatus.UNAVAILABLE;
    }

    public static boolean ensureDownloaded(Context c) {
        if (!isSdkPresent()) return false;
        try {
            GenerativeModelFutures gm = client();
            int status = checkStatusBlocking(c);
            if (status == FeatureStatus.AVAILABLE) return true;
            if (status != FeatureStatus.DOWNLOADABLE && status != FeatureStatus.DOWNLOADING) {
                return false;
            }
            final AtomicReference<Throwable> fail = new AtomicReference<>();
            final Object done = new Object();
            final boolean[] completed = {false};
            gm.download(new DownloadCallback() {
                @Override public void onDownloadStarted(long bytesToDownload) {
                    Log.i(TAG, "Nano download started, bytes=" + bytesToDownload);
                }
                @Override public void onDownloadProgress(long bytesDownloaded) {
                    Log.d(TAG, "Nano download progress=" + bytesDownloaded);
                }
                @Override public void onDownloadCompleted() {
                    synchronized (done) {
                        completed[0] = true;
                        done.notifyAll();
                    }
                }
                @Override public void onDownloadFailed(GenAiException e) {
                    fail.set(e);
                    synchronized (done) {
                        completed[0] = true;
                        done.notifyAll();
                    }
                }
            });
            synchronized (done) {
                if (!completed[0]) done.wait(5 * 60 * 1000L);
            }
            if (fail.get() != null) {
                Log.e(TAG, "Nano download failed: " + fail.get().getMessage());
                return false;
            }
            return checkStatusBlocking(c) == FeatureStatus.AVAILABLE;
        } catch (Throwable t) {
            Log.e(TAG, "ensureDownloaded: " + t.getMessage());
            return false;
        }
    }

    public static String generate(Context c, String prompt, int maxOutputTokens) {
        if (prompt == null || prompt.trim().isEmpty()) return null;
        if (!isSdkPresent()) return null;
        synchronized (GEN_LOCK) {
            try {
                GenerativeModelFutures gm = client();
                int status = checkStatusBlocking(c);
                if (status == FeatureStatus.DOWNLOADABLE) {
                    if (!ensureDownloaded(c)) return null;
                } else if (status != FeatureStatus.AVAILABLE) {
                    return null;
                }

                GenerateContentRequest.Builder b = new GenerateContentRequest.Builder(
                        new TextPart(prompt.trim()));
                // Optional knobs — ignore if API surface differs between beta versions
                try { b.getClass().getMethod("setTemperature", float.class).invoke(b, 0.2f); } catch (Throwable ignored) {}
                try { b.getClass().getMethod("setMaxOutputTokens", int.class)
                        .invoke(b, Math.max(32, Math.min(maxOutputTokens, 1024))); } catch (Throwable ignored) {}
                GenerateContentRequest request = b.build();

                ListenableFuture<GenerateContentResponse> future = gm.generateContent(request);
                GenerateContentResponse response = future.get(90, TimeUnit.SECONDS);
                if (response == null) return null;
                String text = response.getText();
                if (text == null || text.trim().isEmpty()) {
                    try {
                        if (response.getCandidates() != null && !response.getCandidates().isEmpty()) {
                            Object cand = response.getCandidates().get(0);
                            try {
                                text = (String) cand.getClass().getMethod("getText").invoke(cand);
                            } catch (Throwable ignored) {}
                        }
                    } catch (Throwable ignored) {}
                }
                if (text == null || text.trim().isEmpty()) return null;
                return text.trim();
            } catch (Throwable t) {
                Log.e(TAG, "generate failed: " + t.getMessage());
                return null;
            }
        }
    }

    public static String editTranscript(Context c, String rawAsr) {
        if (rawAsr == null || rawAsr.trim().isEmpty()) return null;
        String full = EDITOR_PROMPT + "\n\nТекст:\n" + rawAsr.trim();
        String out = generate(c, full, Math.max(96, Math.min(512, rawAsr.length() / 2 + 64)));
        if (out == null) return null;
        if (out.startsWith("Ты профессиональный") || out.contains("Выдавай только готовый")) return null;
        return out;
    }

    public static String hourlyReport24h(Context c, String archiveText) {
        if (archiveText == null || archiveText.trim().isEmpty()) return null;
        String prompt = "Ты аналитик. Сделай краткий пересказ всех записей за последние 24 часа, "
                + "сгруппировав по часам где возможно. Выдели ключевые темы, задачи и договорённости. "
                + "Выдай только готовый пересказ без пояснений.\n\n" + archiveText.trim();
        return generate(c, prompt, 512);
    }

    public static String shorten(Context c, String text) {
        if (text == null || text.trim().isEmpty()) return null;
        String prompt = "Сократи следующий текст до 2–4 коротких предложений, сохранив только ключевые факты и смысл. "
                + "Выдай только сокращённый текст без пояснений.\n\n" + text.trim();
        return generate(c, prompt, 160);
    }

    public static String answer(Context c, String question, String context) {
        if (question == null || question.trim().isEmpty()) return null;
        String prompt = "Ответь на вопрос пользователя, опираясь только на приведённый архив записей. "
                + "Если ответа нет в архиве — скажи об этом кратко. Без пояснений от себя.\n\n"
                + "Вопрос: " + question.trim() + "\n\nАрхив:\n"
                + (context == null ? "" : context);
        return generate(c, prompt, 320);
    }

    public static String statusLabel(Context c) {
        if (!isSdkPresent()) return "ML Kit GenAI · не в сборке";
        try {
            int s = checkStatusBlocking(c);
            if (s == FeatureStatus.AVAILABLE) return "Gemini Nano · готов";
            if (s == FeatureStatus.DOWNLOADABLE) return "Gemini Nano · можно скачать";
            if (s == FeatureStatus.DOWNLOADING) return "Gemini Nano · скачивается…";
            return "Gemini Nano · недоступен на устройстве";
        } catch (Throwable t) {
            return "Gemini Nano · ошибка проверки";
        }
    }

    public static String detailedStatus(Context c) {
        StringBuilder sb = new StringBuilder();
        boolean pkg = isAicorePackageInstalled(c);
        boolean sdk = isSdkPresent();
        boolean likely = deviceLikelyHasGalaxyAi(c);
        String man = Build.MANUFACTURER != null ? Build.MANUFACTURER : "?";
        String model = Build.MODEL != null ? Build.MODEL : "?";

        String featureLine = "не проверен";
        if (sdk) {
            try {
                int s = checkStatusBlocking(c);
                if (s == FeatureStatus.AVAILABLE) featureLine = "AVAILABLE (готов к вызовам)";
                else if (s == FeatureStatus.DOWNLOADABLE) featureLine = "DOWNLOADABLE (нужна загрузка фичи)";
                else if (s == FeatureStatus.DOWNLOADING) featureLine = "DOWNLOADING";
                else featureLine = "UNAVAILABLE";
            } catch (Throwable t) {
                featureLine = "ошибка: " + (t.getMessage() != null ? t.getMessage() : t.getClass().getSimpleName());
            }
        }

        sb.append("ML Kit GenAI Prompt API (Gemini Nano)\n");
        sb.append("• SDK в APK: ").append(sdk ? "да" : "нет").append("\n");
        sb.append("• FeatureStatus: ").append(featureLine).append("\n");
        sb.append("• Пакет AICore: ").append(pkg ? "установлен" : "не найден").append("\n");
        sb.append("• Устройство: ").append(man).append(" · ").append(model).append("\n");
        sb.append("• Galaxy/Pixel hint: ").append(likely ? "да" : "нет").append("\n");
        if (sdk) {
            boolean ready = false;
            try { ready = checkStatusBlocking(c) == FeatureStatus.AVAILABLE; } catch (Throwable ignored) {}
            sb.append("• Редактор ASR: ").append(ready ? "Gemini Nano" : "только Whisper").append("\n");
            sb.append("• Отчёты / поиск: ").append(ready ? "Gemini Nano" : "эвристика");
        } else {
            sb.append("• Редактор ASR: только Whisper\n");
            sb.append("• Отчёты / поиск: эвристика");
        }
        return sb.toString();
    }
}
