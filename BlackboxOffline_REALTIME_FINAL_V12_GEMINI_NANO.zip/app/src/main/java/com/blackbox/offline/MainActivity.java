package com.blackbox.offline;

import android.animation.ValueAnimator;
import android.media.MediaPlayer;
import java.io.File;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.app.*;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.text.TextUtils;
import android.text.InputType;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.os.*;
import android.util.TypedValue;
import android.view.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Flagship Monolith Navigation Controller (Single Activity Architecture).
 * Features:
 * - Ultra-responsive Bottom Navigation Bar with glowing amber active indicator
 * - Brutalist Black Screen with classic Blackbox Monolith Logo button (animated pulse/scale)
 * - Native tabs: [Главная] [История] [Сводка] [Поиск] [Модели]
 * - Direct playback suppression in History
 * - Stealth copyright "alim" in Models view
 */
public class MainActivity extends Activity {
    private FrameLayout contentFrame;
    private ImageView logoView;
    private TextView statusDescView;
    private TextView statusBadgeView;
    private TextView livePreviewView;
    private TextView liveDotsView;
    private ObjectAnimator livePulse;
    private final Handler liveAnimHandler = new Handler(Looper.getMainLooper());
    private int liveDotsPhase = 0;
    private boolean liveAnimRunning = false;

    // 3D-style live visualizer under logo
    private LinearLayout visualizerRow;
    private View[] vizBars;
    private ValueAnimator[] vizAnims;
    private boolean vizRunning = false;

    // Bottom Bar Icons & Labels
    private ImageView[] tabIcons;
    private LinearLayout[] tabButtons;
    private View[] tabDots;
    private int currentTab = 0; // 0: Home, 1: History, 2: Summary, 3: Search, 4: Models

    private static final int REQ_IMPORT_WHISPER = 101;
    private static final int REQ_IMPORT_LLM = 102;
    private static final int REQ_IMPORT_VOSK = 103;
    private MediaPlayer player;
    /** Cached 24h summary — do not re-hit Cloud on every tab open. */
    private static String cachedSummary24h;
    private static long cachedSummaryAtMs;

    private Button playBtn;

    private boolean isRecording = false;
    private boolean speakerMediaActive = false;
    private boolean mediaDucked = false;
    private long mediaDuckUntil = 0L;
    private final Handler mediaUiHandler = new Handler(Looper.getMainLooper());
    private final Runnable mediaUiTick = new Runnable() { public void run() { updateHomeUi(); if (isRecording && mediaDucked) mediaUiHandler.postDelayed(this, 1000L); } };

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            isRecording = i.getBooleanExtra("active", isRecording);
            updateHomeUi();
        }
    };

    private final BroadcastReceiver audioStateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            speakerMediaActive = i.getBooleanExtra("speaker_media", false);
            mediaDucked = i.getBooleanExtra("ducked", false);
            mediaDuckUntil = i.getLongExtra("duck_until", 0L);
            updateHomeUi();
        }
    };

    private final BroadcastReceiver liveTextReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            String text = i.getStringExtra("text");
            if (livePreviewView == null) return;
            if (text == null) text = "";
            text = AutoTranscriber.cleanHallucinations(text).trim();
            if (text.isEmpty() || text.length() < 4) {
                if (isRecording && mediaDucked) livePreviewView.setText("приглушено");
                else if (isRecording && speakerMediaActive) livePreviewView.setText("динамики воспроизводят медиа…");
                else livePreviewView.setText(isRecording ? "слушаю…" : "");
            } else {
                // keep last ~3 lines visually compact
                String[] words = text.split("\\s+");
                if (words.length > 36) {
                    StringBuilder sb = new StringBuilder();
                    for (int w = words.length - 36; w < words.length; w++) {
                        if (sb.length() > 0) sb.append(' ');
                        sb.append(words[w]);
                    }
                    text = "…" + sb;
                }
                livePreviewView.setText(text);
            }
            if (isRecording) startLiveAnim();
            else stopLiveAnim();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Warm Whisper during app startup so the first realtime window avoids
        // model/context initialization latency.
        new Thread(() -> LocalAiEngine.warm(this), "blackbox-whisper-warm-ui").start();
        RetentionManager.clean(this);
        resumeStuckTranscriptions();

        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stateReceiver, new IntentFilter(RecordingService.STATE), Context.RECEIVER_NOT_EXPORTED);
            registerReceiver(liveTextReceiver, new IntentFilter(RealtimeTranscriber.LIVE_TEXT), Context.RECEIVER_NOT_EXPORTED);
            registerReceiver(audioStateReceiver, new IntentFilter(RecordingService.AUDIO_STATE), Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(stateReceiver, new IntentFilter(RecordingService.STATE));
            registerReceiver(liveTextReceiver, new IntentFilter(RealtimeTranscriber.LIVE_TEXT));
            registerReceiver(audioStateReceiver, new IntentFilter(RecordingService.AUDIO_STATE));
        }

        speakerMediaActive = RecordingService.speakerMediaActive;
        mediaDucked = RecordingService.mediaDucked;
        mediaDuckUntil = RecordingService.mediaDuckUntil;
        renderMainShell();
        switchTab(0);
    }

    // Записи, зависшие в «Расшифровка…»/«В очереди» после смерти процесса,
    // снова ставим в очередь — иначе они висят вечно.
    private void resumeStuckTranscriptions() {
        try {
            List<Entry> all = new EntryStore(this).all();
            for (Entry e : all) {
                if (e.transcript != null && !e.transcript.isEmpty()) continue;
                String st = e.status == null ? "" : e.status;
                if (st.contains("Расшифровка") || st.contains("В очереди")) {
                    e.status = "В очереди";
                    new EntryStore(this).replace(e);
                    AutoTranscriber.enqueue(this, e);
                }
            }
        } catch (Exception ignored) {}
    }

    private void renderMainShell() {
        RelativeLayout root = new RelativeLayout(this);
        root.setBackgroundColor(UI.COLOR_BG); // Light gray/glass canvas

        // Content Area (Top)
        contentFrame = new FrameLayout(this);
        contentFrame.setId(View.generateViewId());
        RelativeLayout.LayoutParams clp = new RelativeLayout.LayoutParams(-1, -1);
        clp.addRule(RelativeLayout.ALIGN_PARENT_TOP);
        root.addView(contentFrame, clp);

        // Bottom Navigation Bar — floating glass island with restored tab names
        LinearLayout bottomBar = new LinearLayout(this);
        bottomBar.setId(View.generateViewId());
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER);

        GradientDrawable glassBg = new GradientDrawable();
        glassBg.setColor(0xF2FFFFFF);
        glassBg.setCornerRadius(dp(22));
        glassBg.setStroke(dp(1), 0xFFD7DBE0);
        bottomBar.setBackground(glassBg);
        bottomBar.setPadding(dp(6), dp(6), dp(6), dp(6));
        if (Build.VERSION.SDK_INT >= 28) {
            bottomBar.setElevation(dp(6));
            bottomBar.setOutlineAmbientShadowColor(0x33000000);
            bottomBar.setOutlineSpotShadowColor(0x22000000);
        }

        RelativeLayout.LayoutParams blp = new RelativeLayout.LayoutParams(-1, dp(72));
        blp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        blp.leftMargin = dp(16);
        blp.rightMargin = dp(16);
        blp.bottomMargin = dp(14);
        root.addView(bottomBar, blp);

        // Make contentFrame sit above bottomBar
        clp.addRule(RelativeLayout.ABOVE, bottomBar.getId());

        // System window insets: content below status bar, bar above nav gestures
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            contentFrame.setPadding(0, insets.getSystemWindowInsetTop(), 0, 0);
            blp.bottomMargin = dp(12) + insets.getSystemWindowInsetBottom();
            bottomBar.setLayoutParams(blp);
            return insets;
        });

        // Five native tabs with their names restored under the icons.
        String[] icons = new String[]{"ic_nav_home", "ic_nav_history", "ic_nav_summary", "ic_nav_search", "ic_nav_models"};
        String[] labels = new String[]{"Главная", "История", "Сводка", "Поиск", "Модели"};

        tabIcons = new ImageView[5];
        tabButtons = new LinearLayout[5];
        tabDots = new View[5]; // compatibility placeholder

        for (int i = 0; i < 5; i++) {
            final int tabIndex = i;
            LinearLayout btn = new LinearLayout(this);
            btn.setOrientation(LinearLayout.VERTICAL);
            btn.setGravity(Gravity.CENTER);
            btn.setClickable(true);
            btn.setFocusable(true);
            btn.setPadding(dp(3), dp(4), dp(3), dp(3));

            ImageView iv = new ImageView(this);
            int resId = getResources().getIdentifier(icons[i], "drawable", getPackageName());
            if (resId != 0) iv.setImageResource(resId);
            btn.addView(iv, new LinearLayout.LayoutParams(dp(22), dp(22)));

            TextView label = new TextView(this);
            label.setText(labels[i]);
            label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9);
            label.setGravity(Gravity.CENTER);
            label.setMaxLines(1);
            label.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            label.setTextColor(UI.COLOR_NAV_INACTIVE);
            LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(-1, dp(18));
            llp.topMargin = dp(1);
            btn.addView(label, llp);

            tabIcons[i] = iv;
            tabButtons[i] = btn;
            tabDots[i] = label; // repurposed as label reference
            btn.setTag(label);
            btn.setOnClickListener(v -> switchTab(tabIndex));
            bottomBar.addView(btn, new LinearLayout.LayoutParams(0, -1, 1.0f));
        }

        setContentView(root);
    }

    private void switchTab(int index) {
        currentTab = index;

        // Update Bottom Bar: soft amber pill behind active icon, no dots
        for (int i = 0; i < 5; i++) {
            boolean active = (i == index);
            int activeColor = UI.COLOR_NAV_ACTIVE;
            int inactiveColor = UI.COLOR_NAV_INACTIVE;

            tabIcons[i].setColorFilter(active ? activeColor : inactiveColor);
            TextView label = tabButtons[i].getTag() instanceof TextView ? (TextView) tabButtons[i].getTag() : null;
            if (label != null) label.setTextColor(active ? activeColor : inactiveColor);
            if (active) {
                GradientDrawable pill = new GradientDrawable();
                pill.setCornerRadius(dp(14));
                pill.setColor(0x16E77A2B);
                pill.setStroke(dp(1), 0x30E77A2B);
                tabButtons[i].setBackground(pill);
                tabIcons[i].setScaleX(1.05f);
                tabIcons[i].setScaleY(1.05f);
            } else {
                tabButtons[i].setBackground(null);
                tabIcons[i].setScaleX(1f);
                tabIcons[i].setScaleY(1f);
            }
        }

        // Render tab content inside contentFrame
        contentFrame.removeAllViews();
        contentFrame.post(() -> {
            if (contentFrame.getChildCount() > 0) {
                View v = contentFrame.getChildAt(0);
                v.setAlpha(0f);
                v.setTranslationY(dp(14));
                v.animate().alpha(1f).translationY(0f).setDuration(210).start();
            }
        });

        switch (index) {
            case 0:
                renderHomeTab();
                break;
            case 1:
                renderHistoryTab();
                break;
            case 2:
                renderSummaryTab();
                break;
            case 3:
                renderSearchTab();
                break;
            case 4:
                renderModelsTab();
                break;
        }
    }

    // ==========================================
    // TAB 0: HOME SCREEN (BRUTALIST LOGO BUTTON)
    // ==========================================
    private void renderHomeTab() {
        LinearLayout home = new LinearLayout(this);
        home.setOrientation(LinearLayout.VERTICAL);
        home.setGravity(Gravity.CENTER);
        home.setPadding(dp(24), dp(36), dp(24), dp(20));

        // Supplied Blackbox logo — the old generated title treatment is removed.
        ImageView brandLogo = new ImageView(this);
        brandLogo.setImageResource(getResources().getIdentifier("blackbox_logo", "drawable", getPackageName()));
        brandLogo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams brandLp = new LinearLayout.LayoutParams(dp(250), dp(118));
        brandLp.gravity = Gravity.CENTER_HORIZONTAL;
        brandLp.bottomMargin = dp(4);
        home.addView(brandLogo, brandLp);

        statusBadgeView = new TextView(this);
        statusBadgeView.setText("Автономный аудио-архив");
        statusBadgeView.setTextColor(UI.COLOR_TEXT_MUTED);
        statusBadgeView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        statusBadgeView.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        statusBadgeView.setPadding(dp(14), dp(7), dp(14), dp(7));
        statusBadgeView.setBackground(UI.shape(UI.COLOR_SURFACE_ELEVATED, UI.COLOR_BORDER, 22, this));
        LinearLayout.LayoutParams sblp = new LinearLayout.LayoutParams(-2, -2);
        sblp.topMargin = dp(14);
        home.addView(statusBadgeView, sblp);

        // Huge interactive animated Logo Button — elevated with soft warm glow
        FrameLayout logoContainer = new FrameLayout(this);
        int containerSize = dp(160);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(containerSize, containerSize);
        clp.topMargin = dp(36);
        clp.bottomMargin = dp(6);
        logoContainer.setLayoutParams(clp);
        if (Build.VERSION.SDK_INT >= 28) {
            logoContainer.setElevation(dp(12));
            logoContainer.setOutlineAmbientShadowColor(0xFF1A0A00);
            logoContainer.setOutlineSpotShadowColor(0xFF3A1400);
        }

        logoView = new ImageView(this);
        logoView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logoView.setClickable(true);
        logoView.setFocusable(true);
        FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(-1, -1);
        logoContainer.addView(logoView, flp);

        logoView.setOnClickListener(v -> toggleRecordingAnimated());
        home.addView(logoContainer);

        // ═══ 3D Live Visualizer ═══
        // Frame with soft glow disk + perspective bars that pulse & tilt in depth
        FrameLayout vizContainer = new FrameLayout(this);
        LinearLayout.LayoutParams vclp = new LinearLayout.LayoutParams(dp(200), dp(64));
        vclp.topMargin = dp(2);
        vclp.bottomMargin = dp(6);
        vizContainer.setLayoutParams(vclp);

        // Soft ambient glow disk (behind bars)
        View glowDisk = new View(this);
        GradientDrawable glowShape = new GradientDrawable();
        glowShape.setShape(GradientDrawable.OVAL);
        glowShape.setColors(new int[]{0x20E77A2B, 0x003B424A});
        glowShape.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        glowShape.setGradientRadius(dp(90));
        glowDisk.setBackground(glowShape);
        glowDisk.setAlpha(0f);
        FrameLayout.LayoutParams glp = new FrameLayout.LayoutParams(dp(160), dp(40));
        glp.gravity = Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM;
        glp.bottomMargin = dp(4);
        vizContainer.addView(glowDisk, glp);

        visualizerRow = new LinearLayout(this);
        visualizerRow.setOrientation(LinearLayout.HORIZONTAL);
        visualizerRow.setGravity(Gravity.CENTER | Gravity.BOTTOM);
        visualizerRow.setPadding(dp(6), 0, dp(6), 0);
        // Enable 3D camera distance for stronger perspective
        if (Build.VERSION.SDK_INT >= 21) {
            visualizerRow.setCameraDistance(dp(2400));
        }
        int barCount = 11;
        vizBars = new View[barCount];
        vizAnims = new ValueAnimator[barCount];
        // Symmetric mountain profile for 3D depth illusion
        int[] baseHeights = {8, 14, 22, 32, 42, 52, 42, 32, 22, 14, 8};
        int[] elevs = {1, 2, 3, 4, 6, 8, 6, 4, 3, 2, 1};
        for (int i = 0; i < barCount; i++) {
            View bar = new View(this);
            GradientDrawable barShape = new GradientDrawable();
            barShape.setCornerRadius(dp(4));
            // Dual-tone: warm amber base → cool live tip
            barShape.setColors(new int[]{0xFF737C86, 0xFFAAB2BB, 0xFFE77A2B});
            barShape.setOrientation(GradientDrawable.Orientation.BOTTOM_TOP);
            bar.setBackground(barShape);
            int h = dp(baseHeights[i]);
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(6), h);
            blp.leftMargin = dp(2);
            blp.rightMargin = dp(2);
            blp.gravity = Gravity.BOTTOM;
            visualizerRow.addView(bar, blp);
            vizBars[i] = bar;
            if (Build.VERSION.SDK_INT >= 28) {
                bar.setElevation(dp(elevs[i]));
                bar.setOutlineAmbientShadowColor(0xFF1A0A00);
                bar.setOutlineSpotShadowColor(0xFF3A1400);
            }
            bar.setAlpha(0.22f);
            bar.setScaleY(0.30f);
            // pivot at bottom so scale grows upward
            bar.setPivotY(h);
        }
        FrameLayout.LayoutParams rlp = new FrameLayout.LayoutParams(-1, -1);
        vizContainer.addView(visualizerRow, rlp);
        // Keep glow reference for live pulse
        vizContainer.setTag(glowDisk);
        home.addView(vizContainer);

        statusDescView = new TextView(this);
        statusDescView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        statusDescView.setTextColor(0xFF6B6B6B);
        statusDescView.setGravity(Gravity.CENTER);
        statusDescView.setLineSpacing(dp(3), 1.0f);
        home.addView(statusDescView);

        // Live preview — layered live card style
        livePreviewView = new TextView(this);
        livePreviewView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        livePreviewView.setTextColor(0xFF4F5862);
        livePreviewView.setGravity(Gravity.CENTER);
        livePreviewView.setMaxLines(3);
        livePreviewView.setEllipsize(TextUtils.TruncateAt.END);
        livePreviewView.setLineSpacing(dp(2), 1.08f);
        livePreviewView.setPadding(dp(18), dp(16), dp(18), dp(14));
        livePreviewView.setText("");
        livePreviewView.setClickable(true);
        livePreviewView.setFocusable(true);
        GradientDrawable liveBg = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFFF0F2F4, 0xFFE7EAED});
        liveBg.setCornerRadius(dp(16));
        liveBg.setStroke(dp(1), 0xFFD0D5DA);
        livePreviewView.setBackground(liveBg);
        if (Build.VERSION.SDK_INT >= 28) {
            livePreviewView.setElevation(dp(4));
            livePreviewView.setOutlineAmbientShadowColor(0x22000000);
            livePreviewView.setOutlineSpotShadowColor(0x18000000);
        }
        livePreviewView.setOnClickListener(v -> {
            try {
                startActivity(new Intent(this, RealtimeRingActivity.class));
                overridePendingTransition(0, 0);
            } catch (Exception ignored) {}
        });
        LinearLayout.LayoutParams lplp = new LinearLayout.LayoutParams(-1, -2);
        lplp.topMargin = dp(12);
        home.addView(livePreviewView, lplp);

        liveDotsView = new TextView(this);
        liveDotsView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        liveDotsView.setTextColor(0xFF000000);
        liveDotsView.setGravity(Gravity.CENTER);
        liveDotsView.setPadding(0, dp(2), 0, 0);
        liveDotsView.setText("");
        home.addView(liveDotsView);

        TextView ringHint = new TextView(this);
        ringHint.setText("тап по тексту → лента 15 мин");
        ringHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        ringHint.setTextColor(0xFF9E9E9E);
        ringHint.setGravity(Gravity.CENTER);
        ringHint.setLetterSpacing(0.06f);
        ringHint.setPadding(0, dp(8), 0, 0);
        home.addView(ringHint);

        if (!ModelManager.installed(this, ModelManager.WHISPER)) {
            TextView warn = new TextView(this);
            warn.setText("⚠ Whisper не установлен — импортируйте модель во вкладке «Модели»");
            warn.setTextColor(0xFF000000);
            warn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            warn.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(-1, -2);
            wlp.topMargin = dp(14);
            home.addView(warn, wlp);
        }

        contentFrame.addView(home, new FrameLayout.LayoutParams(-1, -1));

        isRecording = RecordingService.isRecordingActive;
        updateHomeUi();
    }

    private void toggleRecordingAnimated() {
        // Animate scale bounce
        ValueAnimator anim = ValueAnimator.ofFloat(1.0f, 0.90f, 1.05f, 1.0f);
        anim.setDuration(350);
        anim.setInterpolator(new AccelerateDecelerateInterpolator());
        anim.addUpdateListener(animation -> {
            float s = (float) animation.getAnimatedValue();
            if (logoView != null) {
                logoView.setScaleX(s);
                logoView.setScaleY(s);
            }
        });
        anim.start();

        if (isRecording) {
            startService(new Intent(this, RecordingService.class).setAction(RecordingService.STOP));
        } else {
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                startRecordingService();
            } else {
                requestPermissions(new String[]{
                        android.Manifest.permission.RECORD_AUDIO,
                        Build.VERSION.SDK_INT >= 33 ? android.Manifest.permission.POST_NOTIFICATIONS : android.Manifest.permission.RECORD_AUDIO
                }, 42);
            }
        }
    }

    private void startRecordingService() {
        Intent i = new Intent(this, RecordingService.class).setAction(RecordingService.START);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }
        isRecording = true;
        updateHomeUi();
    }

    private void updateHomeUi() {
        if (logoView == null || statusDescView == null) return;

        if (isRecording) {
            int logoRes = getResources().getIdentifier("blackbox_mark", "drawable", getPackageName());
            if (logoRes != 0) logoView.setImageResource(logoRes);
            if (mediaDucked) {
                statusBadgeView.setText("●  Приглушено");
                statusBadgeView.setTextColor(0xFF000000);
                statusBadgeView.setBackground(UI.shape(0x22FF8A3D, 0xFF5A321F, 20, this));
                long left = Math.max(0L, mediaDuckUntil - System.currentTimeMillis());
                long sec = (left + 999L) / 1000L;
                long min = sec / 60L; sec %= 60L;
                statusDescView.setText(String.format(java.util.Locale.getDefault(), "Медиа приглушено · %02d:%02d\nСкажите «верни звук» для досрочного восстановления.", min, sec));
            } else if (speakerMediaActive) {
                statusBadgeView.setText("●  Динамики заняты");
                statusBadgeView.setTextColor(UI.COLOR_LIVE);
                statusBadgeView.setBackground(UI.shape(UI.COLOR_LIVE_DIM, UI.COLOR_LIVE_BORDER, 20, this));
                statusDescView.setText("Динамики воспроизводят медиа…\nСкажите «отключи микрофон» — приглушить на 10 минут.");
            } else {
                statusBadgeView.setText("●  Слушаю в фоне");
                statusBadgeView.setTextColor(0xFFEF4444);
                statusBadgeView.setBackground(UI.shape(0x22EF4444, 0xFF5A1F1F, 20, this));
                statusDescView.setText("Фоновая запись активна.\nСкажите «Чёрный ящик, стоп» или «отключи микрофон».");
            }
            if (livePreviewView != null) {
                if (mediaDucked) livePreviewView.setText("приглушено");
                else if (speakerMediaActive) livePreviewView.setText("динамики воспроизводят медиа…");
                else if (livePreviewView.getText() == null || livePreviewView.getText().length() == 0) livePreviewView.setText("слушаю…");
            }
            startLiveAnim();
            mediaUiHandler.removeCallbacks(mediaUiTick);
            if (mediaDucked) mediaUiHandler.postDelayed(mediaUiTick, 1000L);
        } else {
            int monoRes = getResources().getIdentifier("blackbox_mark_mono", "drawable", getPackageName());
            if (monoRes != 0) logoView.setImageResource(monoRes);
            statusBadgeView.setText("Запись остановлена");
            statusBadgeView.setTextColor(UI.COLOR_TEXT_MUTED);
            statusBadgeView.setBackground(UI.shape(UI.COLOR_SURFACE_ELEVATED, UI.COLOR_BORDER, 20, this));
            statusDescView.setText("Коснитесь логотипа для включения\nфонового прослушивания.");
            if (livePreviewView != null) livePreviewView.setText("");
            if (liveDotsView != null) liveDotsView.setText("");
            stopLiveAnim();
            mediaUiHandler.removeCallbacks(mediaUiTick);
        }
    }

    private void startLiveAnim() {
        if (liveAnimRunning) return;
        liveAnimRunning = true;
        // breathing alpha on preview text
        if (livePreviewView != null) {
            if (livePulse != null) livePulse.cancel();
            livePulse = ObjectAnimator.ofFloat(livePreviewView, View.ALPHA, 0.30f, 1.0f);
            livePulse.setDuration(1100);
            livePulse.setRepeatMode(ValueAnimator.REVERSE);
            livePulse.setRepeatCount(ValueAnimator.INFINITE);
            livePulse.start();
        }
        liveDotsPhase = 0;
        liveAnimHandler.removeCallbacksAndMessages(null);
        liveAnimHandler.post(liveDotsRunnable);
        startVisualizer();
    }

    private void stopLiveAnim() {
        liveAnimRunning = false;
        liveAnimHandler.removeCallbacksAndMessages(null);
        if (livePulse != null) {
            livePulse.cancel();
            livePulse = null;
        }
        if (livePreviewView != null) livePreviewView.setAlpha(1f);
        if (liveDotsView != null) liveDotsView.setText("");
        stopVisualizer();
    }

    private void startVisualizer() {
        if (vizBars == null || vizRunning) return;
        vizRunning = true;

        // Fade in ambient glow disk
        if (visualizerRow != null && visualizerRow.getParent() instanceof FrameLayout) {
            Object tag = ((FrameLayout) visualizerRow.getParent()).getTag();
            if (tag instanceof View) {
                ((View) tag).animate().alpha(0.85f).setDuration(400).start();
            }
        }

        // Whole row slight continuous Y-tilt for floating 3D presence
        if (visualizerRow != null && Build.VERSION.SDK_INT >= 21) {
            visualizerRow.setCameraDistance(dp(2400));
            ObjectAnimator tilt = ObjectAnimator.ofFloat(visualizerRow, "rotationY", -8f, 8f);
            tilt.setDuration(2800);
            tilt.setRepeatMode(ValueAnimator.REVERSE);
            tilt.setRepeatCount(ValueAnimator.INFINITE);
            tilt.setInterpolator(new AccelerateDecelerateInterpolator());
            tilt.start();
            visualizerRow.setTag(tilt); // store to cancel later
        }

        for (int i = 0; i < vizBars.length; i++) {
            final View bar = vizBars[i];
            if (bar == null) continue;
            bar.setAlpha(1f);
            if (vizAnims[i] != null) vizAnims[i].cancel();

            // Staggered organic pulse — different phase & amplitude
            float minS = 0.32f + (i % 3) * 0.05f;
            float maxS = 0.92f + (i % 5) * 0.06f;
            if (maxS > 1.25f) maxS = 1.25f;

            ValueAnimator va = ValueAnimator.ofFloat(minS, maxS);
            va.setDuration(320 + (i * 47) % 180);
            va.setRepeatMode(ValueAnimator.REVERSE);
            va.setRepeatCount(ValueAnimator.INFINITE);
            va.setInterpolator(new AccelerateDecelerateInterpolator());
            va.setStartDelay(i * 35L);

            final int idx = i;
            final int center = vizBars.length / 2;
            va.addUpdateListener(a -> {
                float s = (float) a.getAnimatedValue();
                bar.setScaleY(s);
                // Stronger 3D: rotationX + slight rotationZ for depth parallax
                if (Build.VERSION.SDK_INT >= 21) {
                    float dist = Math.abs(idx - center);
                    bar.setRotationX((1f - s) * (18f - dist * 1.5f) * ((idx % 2 == 0) ? 1f : -1f));
                    bar.setRotation((1f - s) * 3f * ((idx < center) ? -1f : 1f));
                    // Dynamic elevation pulse
                    if (Build.VERSION.SDK_INT >= 28) {
                        bar.setElevation(dp(2) + s * dp(8));
                    }
                }
            });
            va.start();
            vizAnims[i] = va;
        }
    }

    private void stopVisualizer() {
        vizRunning = false;
        if (vizBars == null) return;

        // Fade out glow
        if (visualizerRow != null && visualizerRow.getParent() instanceof FrameLayout) {
            Object tag = ((FrameLayout) visualizerRow.getParent()).getTag();
            if (tag instanceof View) {
                ((View) tag).animate().alpha(0f).setDuration(350).start();
            }
            // Cancel row tilt
            Object tiltTag = visualizerRow.getTag();
            if (tiltTag instanceof ObjectAnimator) {
                ((ObjectAnimator) tiltTag).cancel();
                visualizerRow.setRotationY(0f);
            }
        }

        for (int i = 0; i < vizBars.length; i++) {
            if (vizAnims[i] != null) {
                vizAnims[i].cancel();
                vizAnims[i] = null;
            }
            View bar = vizBars[i];
            if (bar != null) {
                bar.animate()
                        .scaleY(0.30f)
                        .alpha(0.22f)
                        .rotationX(0f)
                        .rotation(0f)
                        .setDuration(320)
                        .start();
                if (Build.VERSION.SDK_INT >= 28) {
                    bar.setElevation(dp(1));
                }
            }
        }
    }

    private final Runnable liveDotsRunnable = new Runnable() {
        @Override public void run() {
            if (!liveAnimRunning || liveDotsView == null) return;
            String[] frames = {"● ○ ○", "○ ● ○", "○ ○ ●"};
            liveDotsView.setText(frames[liveDotsPhase % 3]);
            liveDotsPhase++;
            liveAnimHandler.postDelayed(this, 380);
        }
    };

    // ==========================================
    // TAB 1: HISTORY (WITH AUDIO GATE ON PLAY)
    // ==========================================
    private void renderHistoryTab() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int padH = dp(18);
        int padV = dp(22);
        content.setPadding(padH, padV, padH, dp(96));

        // Header row: title left + realtime ring button top-right
        LinearLayout headerRow = new LinearLayout(this);
        headerRow.setOrientation(LinearLayout.HORIZONTAL);
        headerRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("История событий");
        title.setTextColor(UI.COLOR_TEXT_TITLE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, -2, 1f);
        headerRow.addView(title, tlp);

        // Top-right design button → 15-min realtime ring (works even when listening is off)
        Button ringBtn = new Button(this);
        ringBtn.setText("◎  Лента");
        ringBtn.setTextColor(UI.COLOR_LIVE);
        ringBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        ringBtn.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        ringBtn.setAllCaps(false);
        GradientDrawable ringBg = new GradientDrawable();
        ringBg.setCornerRadius(dp(16));
        ringBg.setColor(0x16E77A2B);
        ringBg.setStroke(dp(1), UI.COLOR_LIVE_BORDER);
        ringBtn.setBackground(new RippleDrawable(
                ColorStateList.valueOf(0x30E77A2B), ringBg, null));
        int rPadH = dp(14);
        int rPadV = dp(9);
        ringBtn.setPadding(rPadH, rPadV, rPadH, rPadV);
        if (Build.VERSION.SDK_INT >= 28) {
            ringBtn.setElevation(dp(4));
            ringBtn.setOutlineAmbientShadowColor(0x22000000);
            ringBtn.setOutlineSpotShadowColor(0x18000000);
        }
        UI.attachPressScale(ringBtn);
        ringBtn.setOnClickListener(v -> {
            try {
                startActivity(new Intent(this, RealtimeRingActivity.class));
                overridePendingTransition(0, 0);
            } catch (Exception ignored) {}
        });
        headerRow.addView(ringBtn, new LinearLayout.LayoutParams(-2, -2));

        content.addView(headerRow);

        ArrayList<Entry> allEntries = new EntryStore(this).all();
        ArrayList<Entry> entries = new ArrayList<>();
        int pending = 0;
        for (Entry e : allEntries) {
            String clean0 = AutoTranscriber.cleanHallucinations(e.transcript);
            boolean ready = clean0 != null && clean0.trim().length() >= 3
                    && (e.status == null || !e.status.contains("Расшифр") && !e.status.contains("очеред")
                        && !e.status.contains("Обработка") && !e.status.contains("Финальн"));
            // Prefer explicit Готово; also accept any polished text without intermediate status
            if (clean0 != null && clean0.trim().length() >= 3
                    && (e.status == null || "Готово".equals(e.status)
                        || (!e.status.contains("Расшифр") && !e.status.contains("очеред")
                            && !e.status.contains("Обработка") && !e.status.contains("Финальн")
                            && !e.status.contains("Нет модели")))) {
                entries.add(e);
            } else if (e.status != null && (e.status.contains("Расшифр") || e.status.contains("очеред")
                    || e.status.contains("Обработка") || e.status.contains("Финальн"))) {
                pending++;
            } else if (clean0 == null || clean0.trim().length() < 3) {
                pending++;
            }
        }

        TextView countView = new TextView(this);
        String countText = "Готовых фрагментов: " + entries.size();
        if (pending > 0) countText += " · ещё обрабатывается " + pending;
        int cloudWait = 0;
        for (Entry x : entries) { if (x.cloudPending) cloudWait++; }
        if (cloudWait > 0) countText += " · ждут облако " + cloudWait;
        countText += " · " + NetworkStatus.label(this);
        countView.setText(countText);
        countView.setTextColor(0xFF6B6B6B);
        countView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        countView.setPadding(0, dp(3), 0, dp(16));
        content.addView(countView);
        AutoTranscriber.processCloudPendingQueue(this);

        if (entries.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText(pending > 0
                    ? "Архив дополняется. Готовых карточек пока нет — дождитесь обработки."
                    : "В архиве пока нет записей. Включите запись на главном экране или часах.");
            empty.setTextColor(0xFF9E9E9E);
            empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            empty.setPadding(0, dp(40), 0, 0);
            content.addView(empty);
        } else {
            for (Entry e : entries) {
                String clean = AutoTranscriber.cleanHallucinations(e.transcript);
                boolean hasText = clean.length() >= 2;

                LinearLayout card = UI.createCard(this);

                LinearLayout meta = new LinearLayout(this);
                meta.setOrientation(LinearLayout.HORIZONTAL);
                meta.setGravity(Gravity.CENTER_VERTICAL);

                TextView timeBadge = UI.badge(this, e.created, 0xFF000000, 0xFF111111);
                meta.addView(timeBadge);

                TextView catBadge = UI.badge(this, e.category, Color.WHITE, 0xFFF0F0F0);
                LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-2, -2);
                clp.leftMargin = dp(8);
                meta.addView(catBadge, clp);

                if (e.cloudPending) {
                    TextView waitBadge = UI.badge(this,
                            NetworkStatus.isOnline(this) ? "ждёт облако" : "offline",
                            0xFF111111, 0xFFEEEEEE);
                    LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(-2, -2);
                    wlp.leftMargin = dp(8);
                    meta.addView(waitBadge, wlp);
                }

                card.addView(meta);

                TextView tv = new TextView(this);
                if (hasText) {
                    // Уже Whisper (+ Gemini Nano, если доступен на устройстве)
                    tv.setText(clean);
                    tv.setTextColor(0xFF111111);
                } else {
                    String st = (e.status == null || e.status.isEmpty()) ? "В очереди" : e.status;
                    boolean modelMissing = !ModelManager.installed(this, ModelManager.WHISPER);
                    tv.setText(modelMissing
                            ? st + "\nИмпортируйте модель Whisper во вкладке «Модели», чтобы расшифровка работала."
                            : st);
                    tv.setTextColor(0xFF6B6B6B);
                }
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
                tv.setLineSpacing(dp(3), 1.0f);
                tv.setPadding(0, dp(10), 0, dp(12));
                card.addView(tv);

                // Gesture UX: tap = play/pause, long-press = copy, swipe = delete
                final File af = (e.path != null && !e.path.isEmpty()) ? new File(e.path) : null;
                final String copyText = clean;
                final String entryId = e.id;
                final boolean isPending = !hasText;

                if (isPending) {
                    LinearLayout row2 = new LinearLayout(this);
                    row2.setOrientation(LinearLayout.HORIZONTAL);
                    Button retryBtn = UI.secondaryButton(this, "Повторить");
                    retryBtn.setOnClickListener(v -> {
                        e.status = "В очереди";
                        new EntryStore(this).replace(e);
                        AutoTranscriber.enqueue(this, e);
                        Toast.makeText(this, "Запись снова в очереди на расшифровку", Toast.LENGTH_SHORT).show();
                        switchTab(1);
                    });
                    row2.addView(retryBtn);
                    LinearLayout.LayoutParams r2lp = new LinearLayout.LayoutParams(-2, -2);
                    r2lp.topMargin = dp(8);
                    card.addView(row2, r2lp);
                }

                TextView gestureHint = new TextView(this);
                gestureHint.setText("тап · play  ·  удерж. · копировать  ·  свайп · удалить");
                gestureHint.setTextColor(0xFFB0B0B0);
                gestureHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
                gestureHint.setPadding(0, dp(2), 0, 0);
                card.addView(gestureHint);

                final float[] touchX = {0f};
                final boolean[] swiping = {false};
                card.setOnTouchListener((v, ev) -> {
                    switch (ev.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            touchX[0] = ev.getX();
                            swiping[0] = false;
                            v.getParent().requestDisallowInterceptTouchEvent(false);
                            break;
                        case MotionEvent.ACTION_MOVE: {
                            float dx = ev.getX() - touchX[0];
                            if (Math.abs(dx) > dp(12)) {
                                swiping[0] = true;
                                v.getParent().requestDisallowInterceptTouchEvent(true);
                            }
                            if (swiping[0]) {
                                v.setTranslationX(dx);
                                float alpha = Math.max(0.35f, 1f - Math.abs(dx) / (v.getWidth() * 0.7f));
                                v.setAlpha(alpha);
                            }
                            break;
                        }
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL: {
                            float dx = ev.getX() - touchX[0];
                            if (swiping[0] && Math.abs(dx) > v.getWidth() * 0.35f) {
                                v.animate().translationX(dx > 0 ? v.getWidth() : -v.getWidth())
                                        .alpha(0f).setDuration(180)
                                        .withEndAction(() -> {
                                            new EntryStore(MainActivity.this).delete(entryId);
                                            switchTab(1);
                                        }).start();
                                return true;
                            }
                            v.animate().translationX(0f).alpha(1f).setDuration(150).start();
                            break;
                        }
                    }
                    return false; // allow click / long-click
                });

                card.setOnClickListener(v -> {
                    if (af != null && af.isFile()) {
                        togglePlaybackFile(af);
                    } else if (hasText) {
                        Toast.makeText(this, "Аудиофайл недоступен", Toast.LENGTH_SHORT).show();
                    }
                });

                card.setOnLongClickListener(v -> {
                    if (copyText != null && copyText.length() >= 1) {
                        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("blackbox", copyText));
                        Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show();
                    }
                    return true;
                });

                LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
                cardLp.bottomMargin = dp(12);
                card.setAlpha(0f);
                card.setTranslationY(dp(22));
                card.animate().alpha(1f).translationY(0f)
                        .setDuration(210)
                        .setStartDelay(Math.abs((e.id == null ? "x" : e.id).hashCode() % 6) * 35L)
                        .start();
                content.addView(card, cardLp);
            }
        }

        scroll.addView(content);
        contentFrame.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
    }

    // ==========================================
    // TAB 2: SUMMARY (BRUTALIST EXECUTIVE BRIEF)
    // ==========================================
    private void renderSummaryTab() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int padH = dp(18);
        int padV = dp(24);
        content.setPadding(padH, padV, padH, dp(80));

        TextView title = new TextView(this);
        title.setText("Аналитический отчёт");
        title.setTextColor(Color.BLACK);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        content.addView(title);

        boolean nanoOk = GeminiNanoEngine.isAvailable(this);
        boolean cloudOk = CloudGeminiEngine.isConfigured(this);
        String net = NetworkStatus.shortLabel(this);
        TextView subtitle = new TextView(this);
        if (nanoOk) {
            subtitle.setText("Пересказ за 24 ч · Gemini Nano · сеть " + net);
        } else if (cloudOk) {
            subtitle.setText("Пересказ за 24 ч · Cloud Gemini · сеть " + net);
        } else {
            subtitle.setText("Пересказ за 24 ч · эвристика · сеть " + net);
        }
        subtitle.setTextColor(0xFF6B6B6B);
        subtitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        subtitle.setPadding(0, dp(4), 0, dp(12));
        content.addView(subtitle);

        long now = System.currentTimeMillis();
        long cutoff = now - 24L * 60L * 60L * 1000L;
        List<Entry> last24h = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -1);
        String yesterday = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime());
        for (Entry e : new EntryStore(this).all()) {
            if (e.transcript == null || e.transcript.trim().isEmpty()) continue;
            try {
                if (e.created != null) {
                    Date d = sdf.parse(e.created.length() >= 19 ? e.created.substring(0, 19) : e.created);
                    if (d != null && d.getTime() >= cutoff) {
                        last24h.add(e);
                        continue;
                    }
                }
            } catch (Exception ignored) {}
            if (e.created != null && (e.created.startsWith(today) || e.created.startsWith(yesterday))) {
                last24h.add(e);
            }
        }

        if (last24h.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("За последние 24 часа пока нет готовых записей для синтеза.");
            empty.setTextColor(0xFF9E9E9E);
            empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            empty.setPadding(0, dp(30), 0, 0);
            content.addView(empty);
        } else {
            LinearLayout briefCard = UI.createCard(this);
            TextView bTitle = new TextView(this);
            bTitle.setText("ПЕРЕСКАЗ · 24 ЧАСА");
            bTitle.setTextColor(0xFF000000);
            bTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            bTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            briefCard.addView(bTitle);

            TextView bText = new TextView(this);
            bText.setTextColor(0xFF111111);
            bText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            bText.setLineSpacing(dp(4), 1.0f);
            bText.setPadding(0, dp(10), 0, 0);

            // Use cache if still fresh (< 30 min) — no Cloud hit on tab switch
            boolean cacheFresh = cachedSummary24h != null && !cachedSummary24h.isEmpty()
                    && (now - cachedSummaryAtMs) < 30L * 60L * 1000L;
            if (cacheFresh) {
                bText.setText(cachedSummary24h);
            } else {
                bText.setText("Нажмите «Сформировать пересказ», чтобы запросить Cloud (кэш 30 мин).");
            }
            briefCard.addView(bText);

            Button genBtn = UI.primaryButton(this, cacheFresh ? "Обновить пересказ" : "Сформировать пересказ");
            LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(-1, -2);
            glp.topMargin = dp(14);
            briefCard.addView(genBtn, glp);

            Button shortenBtn = UI.secondaryButton(this, "✂ Сократить пересказ");
            LinearLayout.LayoutParams sblp = new LinearLayout.LayoutParams(-1, -2);
            sblp.topMargin = dp(8);
            shortenBtn.setEnabled(cacheFresh);
            briefCard.addView(shortenBtn, sblp);

            final List<Entry> entriesCopy = new ArrayList<>(last24h);
            genBtn.setOnClickListener(v -> {
                genBtn.setEnabled(false);
                genBtn.setText("Формирую…");
                bText.setText("Запрос к Cloud Gemini…");
                new Thread(() -> {
                    LocalAiEngine ai = new LocalAiEngine(this);
                    String report = ai.hourlyReport24h(entriesCopy);
                    // strip residual markdown if model still emits it
                    if (report != null) {
                        report = report.replace("**", "").replace("* ", "• ").trim();
                    }
                    final String out = report != null ? report : "Не удалось получить пересказ.";
                    cachedSummary24h = out;
                    cachedSummaryAtMs = System.currentTimeMillis();
                    runOnUiThread(() -> {
                        bText.setText(out);
                        genBtn.setEnabled(true);
                        genBtn.setText("Обновить пересказ");
                        shortenBtn.setEnabled(true);
                    });
                }).start();
            });

            shortenBtn.setOnClickListener(v -> {
                String current = bText.getText() != null ? bText.getText().toString() : "";
                if (current.isEmpty() || current.startsWith("Нажмите") || current.startsWith("Запрос")) return;
                shortenBtn.setEnabled(false);
                shortenBtn.setText("Сокращаю…");
                final String src = current;
                new Thread(() -> {
                    LocalAiEngine ai = new LocalAiEngine(this);
                    String shortText = ai.shortenSummary(src);
                    if (shortText != null) shortText = shortText.replace("**", "").trim();
                    final String out = shortText != null && shortText.length() >= 3 ? shortText : src;
                    cachedSummary24h = out;
                    cachedSummaryAtMs = System.currentTimeMillis();
                    runOnUiThread(() -> {
                        bText.setText(out);
                        shortenBtn.setText("✂ Сократить пересказ");
                        shortenBtn.setEnabled(true);
                    });
                }).start();
            });

            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, -2);
            blp.topMargin = dp(14);
            blp.bottomMargin = dp(16);
            content.addView(briefCard, blp);
        }

        // No tasks / meetings / chronicle breakdown — plain summary only

        scroll.addView(content);
        contentFrame.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
    }

    private void renderSummaryList(LinearLayout root, String header, List<QwenEngine.SummaryItem> items) {
        if (items == null || items.isEmpty()) return;

        TextView h = new TextView(this);
        h.setText(header);
        h.setTextColor(0xFF6B6B6B);
        h.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        h.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        h.setPadding(dp(4), dp(10), 0, dp(6));
        root.addView(h);

        for (QwenEngine.SummaryItem it : items) {
            LinearLayout itemCard = UI.createCard(this);
            itemCard.setOrientation(LinearLayout.HORIZONTAL);
            itemCard.setGravity(Gravity.CENTER_VERTICAL);
            int pad = dp(12);
            itemCard.setPadding(pad, pad, pad, pad);

            TextView timeView = UI.badge(this, it.time, 0xFF000000, 0xFF111111);
            itemCard.addView(timeView);

            TextView text = new TextView(this);
            text.setText(it.refinedText);
            text.setTextColor(0xFF111111);
            text.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, -2, 1.0f);
            tlp.leftMargin = dp(10);
            itemCard.addView(text, tlp);

            LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
            cardLp.bottomMargin = dp(8);
            root.addView(itemCard, cardLp);
        }
    }

    // ==========================================
    // TAB 3: SEARCH & NATURAL ASSISTANT
    // ==========================================
    private void renderSearchTab() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int padH = dp(18);
        int padV = dp(24);
        content.setPadding(padH, padV, padH, dp(80));

        TextView title = new TextView(this);
        title.setText("Поиск в памяти");
        title.setTextColor(UI.COLOR_TEXT_TITLE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        content.addView(title);

        TextView searchHint = new TextView(this);
        String netS = NetworkStatus.shortLabel(this);
        if (GeminiNanoEngine.isAvailable(this)) {
            searchHint.setText("Ответы через Gemini Nano · сеть " + netS);
        } else if (CloudGeminiEngine.isConfigured(this)) {
            searchHint.setText("Ответы через Cloud Gemini · сеть " + netS);
        } else {
            searchHint.setText("Задайте API ключ в Моделях · сеть " + netS);
        }
        searchHint.setTextColor(0xFF6B6B6B);
        searchHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        searchHint.setPadding(0, dp(4), 0, dp(8));
        content.addView(searchHint);

        EditText input = UI.inputField(this, "Какой код от домофона? О чём говорили?");
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(-1, -2);
        ilp.topMargin = dp(14);
        ilp.bottomMargin = dp(12);
        content.addView(input, ilp);

        TextView resView = new TextView(this);
        resView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        resView.setTextColor(0xFF111111);
        resView.setLineSpacing(dp(3), 1.0f);
        resView.setPadding(dp(12), dp(16), dp(12), dp(16));
        resView.setBackground(UI.shape(0xFFFFFFFF, 0xFFE0E0E0, 14, this));
        resView.setVisibility(View.GONE);

        Button askBtn = UI.primaryButton(this, "Найти в архиве");
        askBtn.setOnClickListener(v -> {
            String q = input.getText().toString().trim();
            if (q.isEmpty()) return;
            askBtn.setEnabled(false);
            resView.setVisibility(View.VISIBLE);
            resView.setText(CloudGeminiEngine.isConfigured(this) || GeminiNanoEngine.isAvailable(this)
                    ? "Ищу через Gemini…" : "Ищу…");
            final String query = q;
            new Thread(() -> {
                StringBuilder archive = new StringBuilder();
                for (Entry e : new EntryStore(this).all()) {
                    if (e.transcript != null && !e.transcript.trim().isEmpty()) {
                        archive.append("[").append(e.created).append("] ")
                               .append(e.transcript.trim()).append("\n\n");
                    }
                }
                LocalAiEngine ai = new LocalAiEngine(this);
                String ans = ai.answer(query, archive.toString());
                runOnUiThread(() -> {
                    resView.setText(ans != null ? ans : "Нет ответа");
                    askBtn.setEnabled(true);
                });
            }).start();
        });
        content.addView(askBtn);

        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, -2);
        rlp.topMargin = dp(16);
        content.addView(resView, rlp);

        scroll.addView(content);
        contentFrame.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
    }

    // ==========================================
    // TAB 4: MODELS & STEALTH COPYRIGHT "ALIM"
    // ==========================================
    private void showEmergencyPhraseDialog() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setText(EmergencySecurity.getPhrase(this));
        input.setSelectAllOnFocus(true);
        input.setHint("Например: Чёрный ящик, тревога");

        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(20), dp(4), dp(20), 0);
        box.addView(input, new LinearLayout.LayoutParams(-1, -2));

        new AlertDialog.Builder(this)
                .setTitle("Секретная фраза")
                .setMessage("Используется для аварийного уничтожения локальных данных.\nНе используй обычную повседневную фразу.")
                .setView(box)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить", (d, which) -> {
                    try {
                        EmergencySecurity.setPhrase(this, input.getText().toString());
                        Toast.makeText(this, "Секретная фраза сохранена", Toast.LENGTH_SHORT).show();
                    } catch (IllegalArgumentException ex) {
                        Toast.makeText(this, "Фраза слишком короткая", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private void renderModelsTab() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        int padH = dp(18);
        int padV = dp(22);
        content.setPadding(padH, padV, padH, dp(96));

        // Header with depth
        TextView title = new TextView(this);
        title.setText("Нейросетевые ядра");
        title.setTextColor(UI.COLOR_TEXT_TITLE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        content.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Локальные модели · Cloud Gemini по желанию · полный контроль");
        subtitle.setTextColor(UI.COLOR_TEXT_MUTED);
        subtitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        subtitle.setPadding(0, dp(4), 0, 0);
        content.addView(subtitle);

        // Status summary strip
        LinearLayout summaryStrip = new LinearLayout(this);
        summaryStrip.setOrientation(LinearLayout.HORIZONTAL);
        summaryStrip.setGravity(Gravity.CENTER_VERTICAL);
        summaryStrip.setPadding(dp(14), dp(12), dp(14), dp(12));
        summaryStrip.setBackground(UI.shape(UI.COLOR_SURFACE_HIGH, UI.COLOR_BORDER_BRIGHT, 16, this));
        UI.elevate(summaryStrip, 2);
        LinearLayout.LayoutParams sslp = new LinearLayout.LayoutParams(-1, -2);
        sslp.topMargin = dp(18);
        sslp.bottomMargin = dp(8);
        content.addView(summaryStrip, sslp);

        boolean voskOk = ModelManager.voskInstalled(this);
        boolean whisperOk = ModelManager.installed(this, ModelManager.WHISPER);
        boolean llmOk = ModelManager.installed(this, ModelManager.LLM);
        int readyCount = (voskOk ? 1 : 0) + (whisperOk ? 1 : 0) + (llmOk ? 1 : 0);

        TextView readyLabel = new TextView(this);
        readyLabel.setText(readyCount + " / 3 готовы");
        readyLabel.setTextColor(readyCount == 3 ? UI.COLOR_GREEN : UI.COLOR_ORANGE);
        readyLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        readyLabel.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        summaryStrip.addView(readyLabel);

        TextView readyHint = new TextView(this);
        readyHint.setText("  ·  импорт из файлового менеджера");
        readyHint.setTextColor(UI.COLOR_TEXT_SUBTLE);
        readyHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        summaryStrip.addView(readyHint);

        // Emergency privacy card
        LinearLayout securityCard = UI.createCard(this);
        LinearLayout securityHead = new LinearLayout(this);
        securityHead.setOrientation(LinearLayout.HORIZONTAL);
        securityHead.setGravity(Gravity.CENTER_VERTICAL);

        TextView securityTitle = new TextView(this);
        securityTitle.setText("🔐 Аварийная защита");
        securityTitle.setTextColor(UI.COLOR_TEXT_TITLE);
        securityTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        securityTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        securityHead.addView(securityTitle, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView securityBadge = UI.badge(this,
                EmergencySecurity.isEnabled(this) ? "активна" : "выкл.",
                EmergencySecurity.isEnabled(this) ? UI.COLOR_ORANGE : UI.COLOR_TEXT_MUTED,
                EmergencySecurity.isEnabled(this) ? UI.COLOR_ORANGE_DIM : 0x22FFFFFF);
        securityHead.addView(securityBadge);
        securityCard.addView(securityHead);

        TextView securityHint = new TextView(this);
        securityHint.setText("Секретная голосовая команда немедленно останавливает запись и уничтожает локальные данные Blackbox.\nФраза хранится локально и может быть изменена ниже.");
        securityHint.setTextColor(UI.COLOR_TEXT_MUTED);
        securityHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        securityHint.setLineSpacing(dp(2), 1.05f);
        securityHint.setPadding(0, dp(8), 0, 0);
        securityCard.addView(securityHint);

        Button phraseBtn = UI.secondaryButton(this, "Изменить секретную фразу");
        phraseBtn.setOnClickListener(v -> showEmergencyPhraseDialog());
        LinearLayout.LayoutParams phraseLp = new LinearLayout.LayoutParams(-1, -2);
        phraseLp.topMargin = dp(12);
        securityCard.addView(phraseBtn, phraseLp);

        Switch securitySwitch = new Switch(this);
        securitySwitch.setText("Разрешить аварийную команду в фоне");
        securitySwitch.setTextColor(UI.COLOR_TEXT_MUTED);
        securitySwitch.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        securitySwitch.setChecked(EmergencySecurity.isEnabled(this));
        securitySwitch.setOnCheckedChangeListener((buttonView, checked) -> {
            EmergencySecurity.setEnabled(this, checked);
            securityBadge.setText(checked ? "активна" : "выкл.");
            securityBadge.setTextColor(checked ? UI.COLOR_ORANGE : UI.COLOR_TEXT_MUTED);
        });
        LinearLayout.LayoutParams ssl = new LinearLayout.LayoutParams(-1, -2);
        ssl.topMargin = dp(6);
        securityCard.addView(securitySwitch, ssl);

        LinearLayout.LayoutParams secLp = new LinearLayout.LayoutParams(-1, -2);
        secLp.topMargin = dp(18);
        secLp.bottomMargin = dp(10);
        content.addView(securityCard, secLp);

        // Vosk Card (live realtime) — elevated live style
        LinearLayout vCard = UI.createLiveCard(this);
        LinearLayout vHead = new LinearLayout(this);
        vHead.setOrientation(LinearLayout.HORIZONTAL);
        vHead.setGravity(Gravity.CENTER_VERTICAL);

        TextView vTitle = new TextView(this);
        vTitle.setText("Vosk · Realtime");
        vTitle.setTextColor(UI.COLOR_TEXT_TITLE);
        vTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        vTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        LinearLayout.LayoutParams vtlp = new LinearLayout.LayoutParams(0, -2, 1f);
        vHead.addView(vTitle, vtlp);

        TextView vBadge = UI.badge(this,
                voskOk ? "активен" : "нет",
                voskOk ? UI.COLOR_LIVE : 0xFFEF4444,
                voskOk ? UI.COLOR_LIVE_DIM : UI.COLOR_RED_BG);
        vHead.addView(vBadge);
        vCard.addView(vHead);

        TextView vStatus = new TextView(this);
        vStatus.setText(ModelManager.voskSize(this));
        vStatus.setTextColor(UI.COLOR_LIVE);
        vStatus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        vStatus.setPadding(0, dp(8), 0, 0);
        vCard.addView(vStatus);

        TextView vHint = new TextView(this);
        vHint.setText("Быстрый live-STT. Импорт: vosk-model-small-ru.zip\nИспользуется для мгновенной ленты на главном экране.");
        vHint.setTextColor(UI.COLOR_TEXT_MUTED);
        vHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        vHint.setLineSpacing(dp(2), 1.05f);
        vHint.setPadding(0, dp(8), 0, 0);
        vCard.addView(vHint);

        Button vImport = UI.primaryButton(this, voskOk ? "Заменить Vosk (.zip)" : "Импортировать Vosk (.zip)");
        vImport.setOnClickListener(v -> pickModelFile(REQ_IMPORT_VOSK));
        LinearLayout.LayoutParams vilp = new LinearLayout.LayoutParams(-1, -2);
        vilp.topMargin = dp(14);
        vCard.addView(vImport, vilp);

        Button vDiag = UI.secondaryButton(this, "Полная диагностика Vosk");
        vDiag.setOnClickListener(v -> VoskDiagnostics.run(this));
        LinearLayout.LayoutParams vdlp = new LinearLayout.LayoutParams(-1, -2);
        vdlp.topMargin = dp(8);
        vCard.addView(vDiag, vdlp);

        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(-1, -2);
        vlp.topMargin = dp(18);
        vlp.bottomMargin = dp(10);
        content.addView(vCard, vlp);

        // Whisper Card (final quality)
        LinearLayout wCard = UI.createCard(this);
        LinearLayout wHead = new LinearLayout(this);
        wHead.setOrientation(LinearLayout.HORIZONTAL);
        wHead.setGravity(Gravity.CENTER_VERTICAL);

        TextView wTitle = new TextView(this);
        wTitle.setText("Whisper · Финальная точность");
        wTitle.setTextColor(UI.COLOR_TEXT_TITLE);
        wTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        wTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        LinearLayout.LayoutParams wtlp = new LinearLayout.LayoutParams(0, -2, 1f);
        wHead.addView(wTitle, wtlp);

        TextView wBadge = UI.badge(this,
                whisperOk ? "готов" : "требуется",
                whisperOk ? UI.COLOR_GREEN : 0xFFEF4444,
                whisperOk ? UI.COLOR_GREEN_BG : UI.COLOR_RED_BG);
        wHead.addView(wBadge);
        wCard.addView(wHead);

        TextView wStatus = new TextView(this);
        wStatus.setText(ModelManager.size(this, ModelManager.WHISPER));
        wStatus.setTextColor(UI.COLOR_ORANGE_CORE);
        wStatus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        wStatus.setPadding(0, dp(8), 0, 0);
        wCard.addView(wStatus);

        if (!whisperOk) {
            TextView wWarn = new TextView(this);
            wWarn.setText("Без этой модели финальная расшифровка недоступна.");
            wWarn.setTextColor(0xFFFF8A8A);
            wWarn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            wWarn.setPadding(0, dp(6), 0, 0);
            wCard.addView(wWarn);
        } else {
            TextView wOk = new TextView(this);
            wOk.setText("Используется после остановки записи для чистого текста.");
            wOk.setTextColor(UI.COLOR_TEXT_MUTED);
            wOk.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            wOk.setPadding(0, dp(6), 0, 0);
            wCard.addView(wOk);
        }

        Button wImport = UI.primaryButton(this, whisperOk ? "Заменить Whisper (.bin)" : "Импортировать Whisper (.bin)");
        wImport.setOnClickListener(v -> pickModelFile(REQ_IMPORT_WHISPER));
        LinearLayout.LayoutParams wilp = new LinearLayout.LayoutParams(-1, -2);
        wilp.topMargin = dp(14);
        wCard.addView(wImport, wilp);

        TextView engineLine = new TextView(this);
        engineLine.setText(LlmEngine.available()
                ? "llama.cpp · native активен"
                : "llama.cpp · шаблонный режим (сборка без native)");
        engineLine.setTextColor(LlmEngine.available() ? UI.COLOR_GREEN : UI.COLOR_TEXT_SUBTLE);
        engineLine.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(-1, -2);
        elp.topMargin = dp(12);
        wCard.addView(engineLine, elp);

        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(-1, -2);
        wlp.topMargin = dp(12);
        wlp.bottomMargin = dp(10);
        content.addView(wCard, wlp);

        // Qwen LLM Card
        LinearLayout qCard = UI.createCard(this);
        LinearLayout qHead = new LinearLayout(this);
        qHead.setOrientation(LinearLayout.HORIZONTAL);
        qHead.setGravity(Gravity.CENTER_VERTICAL);

        TextView qTitle = new TextView(this);
        qTitle.setText("Gemini Nano · AICore");
        qTitle.setTextColor(UI.COLOR_TEXT_TITLE);
        qTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        qTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        LinearLayout.LayoutParams qtlp = new LinearLayout.LayoutParams(0, -2, 1f);
        qHead.addView(qTitle, qtlp);

        boolean nanoOk = GeminiNanoEngine.isAvailable(this);
        TextView qBadge = UI.badge(this,
                nanoOk ? "на устройстве" : "нет на устройстве",
                nanoOk ? UI.COLOR_GREEN : UI.COLOR_TEXT_MUTED,
                nanoOk ? UI.COLOR_GREEN_BG : 0x22FFFFFF);
        qHead.addView(qBadge);
        qCard.addView(qHead);

                TextView qStatus = new TextView(this);
        qStatus.setText(GeminiNanoEngine.detailedStatus(this)
                + (llmOk ? "\n• Опц. GGUF: " + ModelManager.size(this, ModelManager.LLM) : "\n• Опц. GGUF: не установлен")
                + "\n• " + NetworkStatus.label(this));
        qStatus.setTextColor(UI.COLOR_ORANGE_CORE);
        qStatus.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        qStatus.setLineSpacing(dp(2), 1.05f);
        qStatus.setPadding(0, dp(8), 0, 0);
        qCard.addView(qStatus);


        TextView qHint = new TextView(this);
        qHint.setText("Системный Gemini Nano (Pixel AICore / Galaxy AI) правит расшифровки Whisper, строит отчёты и отвечает в поиске.\nЕсли Nano нет — в истории остаётся результат Whisper.");
        qHint.setTextColor(UI.COLOR_TEXT_MUTED);
        qHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        qHint.setLineSpacing(dp(2), 1.05f);
        qHint.setPadding(0, dp(6), 0, 0);
        qCard.addView(qHint);

        Button qImport = UI.secondaryButton(this, llmOk ? "Заменить опциональный GGUF" : "Импортировать опциональный GGUF");
        qImport.setOnClickListener(v -> pickModelFile(REQ_IMPORT_LLM));
        LinearLayout.LayoutParams qilp = new LinearLayout.LayoutParams(-1, -2);
        qilp.topMargin = dp(14);
        qCard.addView(qImport, qilp);

        Button cloudKeyBtn = UI.secondaryButton(this,
                CloudGeminiEngine.isConfigured(this) ? "Cloud Gemini · сменить API ключ" : "Cloud Gemini · ввести API ключ");
        cloudKeyBtn.setOnClickListener(v -> showGeminiApiKeyDialog());
        LinearLayout.LayoutParams cklp = new LinearLayout.LayoutParams(-1, -2);
        cklp.topMargin = dp(10);
        qCard.addView(cloudKeyBtn, cklp);

        Button cloudTestBtn = UI.secondaryButton(this, "Проверить Cloud API");
        cloudTestBtn.setOnClickListener(v -> testCloudGeminiApi(cloudTestBtn));
        LinearLayout.LayoutParams ctlp = new LinearLayout.LayoutParams(-1, -2);
        ctlp.topMargin = dp(8);
        qCard.addView(cloudTestBtn, ctlp);

        Button cloudQueueBtn = UI.secondaryButton(this, "Обработать очередь облака");
        cloudQueueBtn.setOnClickListener(v -> {
            cloudQueueBtn.setEnabled(false);
            cloudQueueBtn.setText("Обработка…");
            AutoTranscriber.processCloudPendingQueue(this);
            cloudQueueBtn.postDelayed(() -> {
                cloudQueueBtn.setEnabled(true);
                cloudQueueBtn.setText("Обработать очередь облака");
                Toast.makeText(this, "Очередь запущена · " + NetworkStatus.label(this), Toast.LENGTH_SHORT).show();
                switchTab(1);
            }, 1500);
        });
        LinearLayout.LayoutParams cqlp = new LinearLayout.LayoutParams(-1, -2);
        cqlp.topMargin = dp(8);
        qCard.addView(cloudQueueBtn, cqlp);

        LinearLayout.LayoutParams qlp = new LinearLayout.LayoutParams(-1, -2);
        qlp.bottomMargin = dp(28);
        content.addView(qCard, qlp);

        // Stealth signature — deeper, less generic


        scroll.addView(content);
        contentFrame.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
    }

    private void testCloudGeminiApi(Button btn) {
        if (!CloudGeminiEngine.isConfigured(this)) {
            Toast.makeText(this, "Сначала введите API ключ", Toast.LENGTH_SHORT).show();
            return;
        }
        btn.setEnabled(false);
        btn.setText("Проверка…");
        new Thread(() -> {
            CloudGeminiEngine.Result r = CloudGeminiEngine.generateDetailed(this,
                    "Ответь одним словом на русском: работает");
            runOnUiThread(() -> {
                btn.setEnabled(true);
                btn.setText("Проверить Cloud API");
                if (r != null && r.text != null && r.text.trim().length() > 0) {
                    Toast.makeText(this,
                            "API OK (" + (r.model != null ? r.model : "?") + "): " + r.text.trim(),
                            Toast.LENGTH_LONG).show();
                } else {
                    String err = (r != null && r.error != null) ? r.error : CloudGeminiEngine.getLastError(this);
                    if (err == null || err.isEmpty()) err = "нет ответа";
                    Toast.makeText(this, "API ошибка: " + err, Toast.LENGTH_LONG).show();
                }
            });
        }).start();
    }

    private void showGeminiApiKeyDialog() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        String existing = CloudGeminiEngine.getApiKey(this);
        if (existing != null && !existing.isEmpty()) {
            input.setText(existing);
            input.setSelection(existing.length());
        }
        input.setHint("AIza... ключ из Google AI Studio");
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(20), dp(4), dp(20), 0);
        box.addView(input, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this)
                .setTitle("Cloud Gemini API ключ")
                .setMessage("Используется только если on-device Nano / Proofreading недоступны.\nКлюч хранится только на устройстве.")
                .setView(box)
                .setNegativeButton("Очистить", (d, w) -> {
                    CloudGeminiEngine.setApiKey(this, "");
                    Toast.makeText(this, "Ключ удалён", Toast.LENGTH_SHORT).show();
                    switchTab(4);
                })
                .setNeutralButton("Отмена", null)
                .setPositiveButton("Сохранить", (d, w) -> {
                    CloudGeminiEngine.setApiKey(this, input.getText().toString());
                    Toast.makeText(this,
                            CloudGeminiEngine.isConfigured(this) ? "Ключ сохранён" : "Ключ слишком короткий",
                            Toast.LENGTH_SHORT).show();
                    switchTab(4);
                })
                .show();
    }

    private void pickModelFile(int req) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        try {
            startActivityForResult(i, req);
        } catch (Exception e) {
            Toast.makeText(this, "Нет приложения для выбора файла", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        Toast.makeText(this, "Копирование весов модели…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                if (req == REQ_IMPORT_VOSK) {
                    ModelManager.importVoskZip(this, uri);
                } else {
                    String target;
                    if (req == REQ_IMPORT_WHISPER) target = ModelManager.WHISPER;
                    else if (req == REQ_IMPORT_LLM) target = ModelManager.LLM;
                    else return;
                    ModelManager.importFile(this, uri, target);
                }
                runOnUiThread(() -> {
                    Toast.makeText(this, "Модель успешно установлена!", Toast.LENGTH_SHORT).show();
                    switchTab(4);
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this,
                        "Ошибка импорта: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void togglePlaybackFile(File f) {
        try {
            if (player != null && player.isPlaying()) {
                player.stop();
                player.release();
                player = null;
                RecordingService.isAppPlayingAudio = false;
                Toast.makeText(this, "Пауза", Toast.LENGTH_SHORT).show();
                return;
            }
            if (player != null) {
                try { player.release(); } catch (Exception ignored) {}
                player = null;
            }
            player = new MediaPlayer();
            RecordingService.isAppPlayingAudio = true;
            player.setDataSource(f.getAbsolutePath());
            player.setOnCompletionListener(mp -> {
                try { mp.release(); } catch (Exception ignored) {}
                player = null;
                RecordingService.isAppPlayingAudio = false;
            });
            player.setOnErrorListener((mp, what, extra) -> {
                try { mp.release(); } catch (Exception ignored) {}
                player = null;
                RecordingService.isAppPlayingAudio = false;
                Toast.makeText(this, "Не удалось воспроизвести запись", Toast.LENGTH_SHORT).show();
                return true;
            });
            player.prepare();
            player.start();
            Toast.makeText(this, "▶ Воспроизведение", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            try { if (player != null) player.release(); } catch (Exception ignored) {}
            player = null;
            RecordingService.isAppPlayingAudio = false;
            Toast.makeText(this, "Ошибка аудио: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void togglePlayback(Button btn, File f) {
        try {
            if (player != null && player.isPlaying()) {
                player.stop();
                player.release();
                player = null;
                RecordingService.isAppPlayingAudio = false;
                resetPlayButtons();
                return;
            }
            resetPlayButtons();
            player = new MediaPlayer();
            RecordingService.isAppPlayingAudio = true;
            player.setDataSource(f.getAbsolutePath());
            player.setOnCompletionListener(mp -> {
                mp.release();
                player = null;
                resetPlayButtons();
            });
            player.setOnErrorListener((mp, what, extra) -> {
                try { mp.release(); } catch (Exception ignored) {}
                player = null;
                RecordingService.isAppPlayingAudio = false;
                resetPlayButtons();
                Toast.makeText(this, "Не удалось воспроизвести запись", Toast.LENGTH_SHORT).show();
                return true;
            });
            player.prepare();
            player.start();
            playBtn = btn;
            btn.setText("■ Стоп");
        } catch (Exception ex) {
            try { if (player != null) player.release(); } catch (Exception ignored) {}
            player = null;
            RecordingService.isAppPlayingAudio = false;
            Toast.makeText(this, "Не удалось воспроизвести запись", Toast.LENGTH_SHORT).show();
        }
    }

    private void resetPlayButtons() {
        if (contentFrame == null) return;
        java.util.ArrayList<Button> found = new java.util.ArrayList<>();
        java.util.ArrayDeque<android.view.View> stack = new java.util.ArrayDeque<>();
        stack.add(contentFrame);
        while (!stack.isEmpty()) {
            android.view.View v = stack.poll();
            if (v instanceof Button) {
                CharSequence cs = ((Button) v).getText();
                if (cs != null && ("■ Стоп".contentEquals(cs) || "Слушать".contentEquals(cs))) {
                    found.add((Button) v);
                }
            } else if (v instanceof android.view.ViewGroup) {
                android.view.ViewGroup g = (android.view.ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++) stack.add(g.getChildAt(i));
            }
        }
        for (Button b : found) b.setText("Слушать");
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null) {
            try { player.stop(); player.release(); } catch (Exception ignored) {}
            player = null;
            resetPlayButtons();
        }
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }


    @Override
    protected void onResume() {
        super.onResume();
        AutoTranscriber.processCloudPendingQueue(this);
    }

    @Override
    protected void onDestroy() {
        try { unregisterReceiver(liveTextReceiver); } catch (Exception ignored) {}
        stopLiveAnim();
        try { unregisterReceiver(stateReceiver); } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
