package com.blackbox.offline;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Looper;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Cloud Gemini via Developer API (API key). Used only when on-device Nano is unavailable.
 * Key stored in SharedPreferences — never hardcoded.
 */
public final class CloudGeminiEngine {
    private static final String TAG = "CloudGemini";
    private static final String PREFS = "blackbox_prefs";
    private static final String KEY_API = "gemini_api_key";
    private static final String MODEL = "gemini-2.0-flash";

    private CloudGeminiEngine() {}

    public static void setApiKey(Context c, String key) {
        SharedPreferences p = c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (key == null || key.trim().isEmpty()) {
            p.edit().remove(KEY_API).apply();
        } else {
            p.edit().putString(KEY_API, key.trim()).apply();
        }
    }

    public static String getApiKey(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_API, "");
    }

    public static boolean isConfigured(Context c) {
        String k = getApiKey(c);
        return k != null && k.length() >= 20;
    }

    public static String statusLabel(Context c) {
        return isConfigured(c) ? "Cloud Gemini · ключ задан" : "Cloud Gemini · ключ не задан";
    }

    /** Blocking HTTP call — background thread only. */
    public static String generate(Context c, String prompt) {
        if (prompt == null || prompt.trim().isEmpty()) return null;
        if (Looper.myLooper() == Looper.getMainLooper()) {
            Log.e(TAG, "generate on main thread refused");
            return null;
        }
        String apiKey = getApiKey(c);
        if (apiKey == null || apiKey.length() < 10) return null;
        HttpURLConnection conn = null;
        try {
            URL url = new URL(
                    "https://generativelanguage.googleapis.com/v1beta/models/"
                            + MODEL + ":generateContent?key=" + apiKey);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(90000);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            conn.setDoOutput(true);

            JSONObject body = new JSONObject();
            JSONArray contents = new JSONArray();
            JSONObject content = new JSONObject();
            JSONArray parts = new JSONArray();
            JSONObject part = new JSONObject();
            part.put("text", prompt.trim());
            parts.put(part);
            content.put("parts", parts);
            contents.put(content);
            body.put("contents", contents);
            JSONObject genConfig = new JSONObject();
            genConfig.put("temperature", 0.2);
            genConfig.put("maxOutputTokens", 1024);
            body.put("generationConfig", genConfig);

            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(bytes);
            }

            int code = conn.getResponseCode();
            BufferedReader br = new BufferedReader(new InputStreamReader(
                    code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream(),
                    StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            String raw = sb.toString();
            if (code < 200 || code >= 300) {
                Log.e(TAG, "HTTP " + code + ": " + raw);
                return null;
            }
            JSONObject resp = new JSONObject(raw);
            JSONArray candidates = resp.optJSONArray("candidates");
            if (candidates == null || candidates.length() == 0) return null;
            JSONObject c0 = candidates.getJSONObject(0);
            JSONObject cont = c0.optJSONObject("content");
            if (cont == null) return null;
            JSONArray p2 = cont.optJSONArray("parts");
            if (p2 == null || p2.length() == 0) return null;
            String text = p2.getJSONObject(0).optString("text", "");
            return text.trim().isEmpty() ? null : text.trim();
        } catch (Throwable t) {
            Log.e(TAG, "cloud generate failed: " + t.getMessage());
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }
}
