package com.blackbox.offline;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Looper;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Cloud Gemini via Developer API (API key).
 * Tries several model ids — gemini-2.0-flash is shut down on Google side.
 */
public final class CloudGeminiEngine {
    private static final String TAG = "CloudGemini";
    private static final String PREFS = "blackbox_prefs";
    private static final String KEY_API = "gemini_api_key";
    private static final String KEY_LAST_ERR = "gemini_last_error";
    private static final String KEY_LAST_MODEL = "gemini_last_model";

    /** Prefer live models first; 2.0-flash is shut down. */
    /** Order: newest first. Dead/shutdown ids cause 404 and are skipped. */
    private static final String[] MODELS = {
            "gemini-3.8-flash",
            "gemini-flash-latest",
            "gemini-2.5-flash",
            "gemini-2.5-flash-lite"
    };

    private CloudGeminiEngine() {}

    public static void setApiKey(Context c, String key) {
        SharedPreferences p = c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (key == null || key.trim().isEmpty()) {
            p.edit().remove(KEY_API).apply();
        } else {
            // strip whitespace / quotes users sometimes paste
            String k = key.trim().replace("\"", "").replace("'", "");
            p.edit().putString(KEY_API, k).apply();
        }
    }

    public static String getApiKey(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_API, "");
    }

    public static boolean isConfigured(Context c) {
        String k = getApiKey(c);
        return k != null && k.length() >= 20;
    }

    public static String getLastError(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_LAST_ERR, "");
    }

    public static String getLastModel(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_LAST_MODEL, "");
    }

    private static void saveDiag(Context c, String err, String model) {
        SharedPreferences p = c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = p.edit();
        if (err != null) ed.putString(KEY_LAST_ERR, err.length() > 300 ? err.substring(0, 300) : err);
        if (model != null) ed.putString(KEY_LAST_MODEL, model);
        ed.apply();
    }

    public static String statusLabel(Context c) {
        return isConfigured(c) ? "Cloud Gemini · ключ задан" : "Cloud Gemini · ключ не задан";
    }

    /** Blocking. Returns text or null. */
    public static String generate(Context c, String prompt) {
        Result r = generateDetailed(c, prompt);
        return r != null ? r.text : null;
    }

    public static final class Result {
        public final String text;
        public final String error;
        public final String model;
        public final int httpCode;
        public Result(String text, String error, String model, int httpCode) {
            this.text = text;
            this.error = error;
            this.model = model;
            this.httpCode = httpCode;
        }
    }

    /** Blocking HTTP — background thread only. Tries multiple models. */
    public static Result generateDetailed(Context c, String prompt) {
        if (prompt == null || prompt.trim().isEmpty()) {
            return new Result(null, "пустой промпт", null, 0);
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            Log.e(TAG, "generate on main thread refused");
            return new Result(null, "вызов с UI-потока запрещён", null, 0);
        }
        String apiKey = getApiKey(c);
        if (apiKey == null || apiKey.length() < 10) {
            return new Result(null, "ключ не задан", null, 0);
        }
        if (!NetworkStatus.isOnline(c)) {
            return new Result(null, "нет сети", null, 0);
        }

        String lastErr = null;
        int lastCode = 0;
        for (String model : MODELS) {
            Result r = callOnce(c, apiKey, model, prompt.trim());
            if (r.text != null && !r.text.isEmpty()) {
                saveDiag(c, "OK", model);
                return r;
            }
            lastErr = r.error;
            lastCode = r.httpCode;
            // 401/403 — bad key, no point trying other models
            if (r.httpCode == 401 || r.httpCode == 403) {
                saveDiag(c, r.error, model);
                return r;
            }
        }
        saveDiag(c, lastErr != null ? lastErr : "нет ответа", null);
        return new Result(null, lastErr != null ? lastErr : "нет ответа", null, lastCode);
    }

    private static Result callOnce(Context c, String apiKey, String model, String prompt) {
        HttpURLConnection conn = null;
        try {
            // Prefer header auth; also put key in query for older gateways
            URL url = new URL(
                    "https://generativelanguage.googleapis.com/v1beta/models/"
                            + model + ":generateContent?key=" + apiKey);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(60000);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            conn.setRequestProperty("x-goog-api-key", apiKey);
            conn.setDoOutput(true);
            conn.setInstanceFollowRedirects(true);

            JSONObject body = new JSONObject();
            JSONArray contents = new JSONArray();
            JSONObject content = new JSONObject();
            JSONArray parts = new JSONArray();
            JSONObject part = new JSONObject();
            part.put("text", prompt);
            parts.put(part);
            content.put("parts", parts);
            contents.put(content);
            body.put("contents", contents);
            JSONObject genConfig = new JSONObject();
            genConfig.put("temperature", 0.2);
            genConfig.put("maxOutputTokens", 1024);
            body.put("generationConfig", genConfig);

            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(bytes);
            }

            int code = conn.getResponseCode();
            InputStream stream = (code >= 200 && code < 300)
                    ? conn.getInputStream()
                    : (conn.getErrorStream() != null ? conn.getErrorStream() : conn.getInputStream());
            String raw = readAll(stream);

            if (code < 200 || code >= 300) {
                String msg = extractErrorMessage(raw, code);
                Log.e(TAG, model + " HTTP " + code + ": " + msg);
                return new Result(null, msg, model, code);
            }

            JSONObject resp = new JSONObject(raw);
            // blocked by safety?
            if (resp.has("promptFeedback")) {
                JSONObject pf = resp.optJSONObject("promptFeedback");
                if (pf != null && pf.has("blockReason")) {
                    return new Result(null, "blocked: " + pf.optString("blockReason"), model, code);
                }
            }
            JSONArray candidates = resp.optJSONArray("candidates");
            if (candidates == null || candidates.length() == 0) {
                return new Result(null, "пустой candidates", model, code);
            }
            JSONObject c0 = candidates.getJSONObject(0);
            String finish = c0.optString("finishReason", "");
            JSONObject cont = c0.optJSONObject("content");
            if (cont == null) {
                return new Result(null, "нет content (" + finish + ")", model, code);
            }
            JSONArray p2 = cont.optJSONArray("parts");
            if (p2 == null || p2.length() == 0) {
                return new Result(null, "нет parts (" + finish + ")", model, code);
            }
            String text = p2.getJSONObject(0).optString("text", "");
            if (text.trim().isEmpty()) {
                return new Result(null, "пустой text (" + finish + ")", model, code);
            }
            Log.i(TAG, model + " OK, chars=" + text.length());
            return new Result(text.trim(), null, model, code);
        } catch (javax.net.ssl.SSLException se) {
            Log.e(TAG, model + " SSL: " + se.getMessage());
            return new Result(null, "SSL: " + se.getMessage(), model, 0);
        } catch (java.net.UnknownHostException uh) {
            return new Result(null, "DNS: нет доступа к Google", model, 0);
        } catch (java.net.SocketTimeoutException te) {
            return new Result(null, "таймаут", model, 0);
        } catch (Throwable t) {
            Log.e(TAG, model + " fail: " + t.getMessage());
            return new Result(null, t.getClass().getSimpleName() + ": " + t.getMessage(), model, 0);
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String readAll(InputStream stream) throws Exception {
        if (stream == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    }

    private static String extractErrorMessage(String raw, int code) {
        if (raw == null || raw.isEmpty()) return "HTTP " + code;
        try {
            JSONObject o = new JSONObject(raw);
            JSONObject err = o.optJSONObject("error");
            if (err != null) {
                String msg = err.optString("message", "");
                String status = err.optString("status", "");
                if (!msg.isEmpty()) {
                    // shorten long Google messages
                    if (msg.length() > 160) msg = msg.substring(0, 157) + "…";
                    return "HTTP " + code + (status.isEmpty() ? "" : " " + status) + ": " + msg;
                }
            }
        } catch (Throwable ignored) {}
        String s = raw.replace('\n', ' ');
        if (s.length() > 160) s = s.substring(0, 157) + "…";
        return "HTTP " + code + ": " + s;
    }
}
